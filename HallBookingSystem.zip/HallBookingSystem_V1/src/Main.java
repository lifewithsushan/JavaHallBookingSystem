import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.Scheduler;
import util.FileManager;
import javax.swing.table.AbstractTableModel;
import java.awt.Window;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new UnifiedLoginFrame();
            }
        });
    }
}

// --- Beautiful Landing Page ---
class LandingPage extends JFrame {
    public LandingPage() {
        setTitle("Hall Booking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Header
        JLabel title = new JLabel("Hall Booking Management System", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 48));
        title.setBorder(BorderFactory.createEmptyBorder(40, 0, 20, 0));
        add(title, BorderLayout.NORTH);

        // Center panel with role buttons
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(30, 30, 30, 30);
        gbc.gridx = 0;
        gbc.gridy = 0;
        JButton schedulerBtn = createRoleButton("Scheduler");
        centerPanel.add(schedulerBtn, gbc);
        gbc.gridx++;
        JButton managerBtn = createRoleButton("Manager");
        centerPanel.add(managerBtn, gbc);
        gbc.gridx++;
        JButton adminBtn = createRoleButton("Administrator");
        centerPanel.add(adminBtn, gbc);
        gbc.gridx++;
        JButton customerBtn = createRoleButton("Customer");
        centerPanel.add(customerBtn, gbc);
        add(centerPanel, BorderLayout.CENTER);

        // Footer
        JLabel footer = new JLabel("© 2024 Hall Booking Company", SwingConstants.CENTER);
        footer.setFont(new Font("SansSerif", Font.PLAIN, 18));
        footer.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(footer, BorderLayout.SOUTH);

        // Button actions
        schedulerBtn.addActionListener(e -> { dispose(); new SchedulerLoginFrame(true); });
        managerBtn.addActionListener(e -> { dispose(); new ManagerLoginFrame(true); });
        adminBtn.addActionListener(e -> { dispose(); new AdminLoginFrame(true); });
        customerBtn.addActionListener(e -> { dispose(); new CustomerLoginFrame(true); });

        setVisible(true);
    }
    private JButton createRoleButton(String role) {
        JButton btn = new JButton(role);
        btn.setFont(new Font("SansSerif", Font.BOLD, 28));
        btn.setPreferredSize(new Dimension(300, 100));
        btn.setFocusPainted(false);
        btn.setBackground(new Color(70, 130, 180));
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(new Color(30, 60, 120), 3));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}

// --- Role Selection Frame ---
class RoleSelectionFrame extends JFrame {
    public RoleSelectionFrame() {
        setTitle("Hall Booking System - Select Role");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 1, 10, 10));
        JLabel label = new JLabel("Select your role to login:", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        add(label);
        JButton schedulerBtn = new JButton("Scheduler");
        JButton managerBtn = new JButton("Manager");
        JButton adminBtn = new JButton("Administrator");
        JButton customerBtn = new JButton("Customer");
        add(schedulerBtn);
        add(managerBtn);
        add(adminBtn);
        add(customerBtn);

        schedulerBtn.addActionListener(e -> { dispose(); new SchedulerLoginFrame(); });
        managerBtn.addActionListener(e -> { dispose(); new ManagerLoginFrame(); });
        adminBtn.addActionListener(e -> { dispose(); new AdminLoginFrame(); });
        customerBtn.addActionListener(e -> { dispose(); new CustomerLoginFrame(); });

        setVisible(true);
    }
}

// --- Scheduler Login Frame ---
class SchedulerLoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;

    public SchedulerLoginFrame() { this(false); }
    public SchedulerLoginFrame(boolean fullWindow) {
        setTitle("Scheduler Login - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (fullWindow) setExtendedState(JFrame.MAXIMIZED_BOTH); else setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);
        JButton loginButton = new JButton("Login");
        formPanel.add(loginButton);
        statusLabel = new JLabel("");
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword());
                Scheduler scheduler = authenticateScheduler(email, password);
                if (scheduler != null) {
                    dispose();
                    new SchedulerDashboardFrame(scheduler);
                } else {
                    statusLabel.setText("Invalid credentials or not a Scheduler.");
                }
            }
        });

        setVisible(true);
    }

    private Scheduler authenticateScheduler(String email, String password) {
        java.util.List<String> users = FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), em = parts[2].trim(), pw = parts[3].trim(), role = parts[4].trim(), status = parts[5].trim();
                if (em.equals(email) && pw.equals(password) && role.equalsIgnoreCase("Scheduler") && status.equalsIgnoreCase("Active")) {
                    return new Scheduler(id, name, em, pw, status);
                }
            }
        }
        return null;
    }
}

// --- Scheduler Dashboard Frame with Sidebar and Hall List ---
class SchedulerDashboardFrame extends JFrame {
    private Scheduler scheduler;
    private JPanel mainContent;
    private JButton hallsBtn, scheduleBtn;
    private JTable hallTable;
    private HallTableModel tableModel;
    private JComboBox<String> typeFilterBox, statusFilterBox;
    private JTextField searchField;
    private JButton applyFilterBtn, refreshBtn, clearFilterBtn;
    // --- Schedules tab fields ---
    private JTable scheduleTable;
    private ScheduleTableModel scheduleTableModel;
    private JComboBox<String> scheduleHallFilterBox, scheduleTypeFilterBox;
    private JTextField scheduleSearchField;
    private JButton scheduleApplyFilterBtn, scheduleRefreshBtn, scheduleClearFilterBtn, addScheduleBtn;

    public SchedulerDashboardFrame(Scheduler scheduler) {
        this.scheduler = scheduler;
        setTitle("Scheduler Dashboard - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(30, 60, 120));
        sidebar.setPreferredSize(new Dimension(320, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));

        JLabel logo = new JLabel("Scheduler", SwingConstants.CENTER);
        logo.setFont(new Font("Serif", Font.BOLD, 32));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(40));

        hallsBtn = new JButton("Manage Halls");
        hallsBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        hallsBtn.setBackground(new Color(245, 247, 250));
        hallsBtn.setForeground(new Color(30, 30, 30));
        hallsBtn.setFocusPainted(false);
        hallsBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        hallsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(hallsBtn);
        sidebar.add(Box.createVerticalStrut(24));

        scheduleBtn = new JButton("Manage Schedules");
        scheduleBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        scheduleBtn.setBackground(new Color(245, 247, 250));
        scheduleBtn.setForeground(new Color(30, 30, 30));
        scheduleBtn.setFocusPainted(false);
        scheduleBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        scheduleBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(scheduleBtn);
        sidebar.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        logoutBtn.setBackground(new Color(220, 38, 38));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);

        // Main content area
        mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(new Color(245, 247, 250));
        add(mainContent, BorderLayout.CENTER);

        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Type:"));
        typeFilterBox = new JComboBox<>(new String[]{"All", "Auditorium", "Banquet", "MeetingRoom"});
        filterPanel.add(typeFilterBox);
        filterPanel.add(new JLabel("Status:"));
        statusFilterBox = new JComboBox<>(new String[]{"All", "Available", "Unavailable", "Maintenance"});
        filterPanel.add(statusFilterBox);
        filterPanel.add(new JLabel("Search (ID/Name):"));
        searchField = new JTextField(12);
        filterPanel.add(searchField);
        applyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(applyFilterBtn);
        refreshBtn = new JButton("Refresh");
        filterPanel.add(refreshBtn);
        clearFilterBtn = new JButton("Clear Filters");
        filterPanel.add(clearFilterBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        // Hall list table (default view)
        tableModel = new HallTableModel();
        hallTable = new JTable(tableModel);
        hallTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        hallTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        hallTable.setRowHeight(32);
        hallTable.setShowGrid(false);
        hallTable.setFillsViewportHeight(true);
        hallTable.setSelectionBackground(new Color(220, 230, 250));
        hallTable.setSelectionForeground(new Color(30, 30, 30));
        hallTable.getColumn("Actions").setCellRenderer(new ActionsRenderer());
        hallTable.getColumn("Actions").setCellEditor(new ActionsEditor(hallTable, tableModel));
        JScrollPane hallScroll = new JScrollPane(hallTable);
        hallScroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(hallScroll, BorderLayout.CENTER);

        // Tab switching
        hallsBtn.addActionListener(e -> showHallList());
        scheduleBtn.addActionListener(e -> showScheduleTab());
        logoutBtn.addActionListener(e -> {
            dispose();
            new UnifiedLoginFrame();
        });

        // Filter/search actions
        applyFilterBtn.addActionListener(e -> tableModel.applyFilter((String)typeFilterBox.getSelectedItem(), (String)statusFilterBox.getSelectedItem(), searchField.getText()));
        refreshBtn.addActionListener(e -> tableModel.loadHalls());
        clearFilterBtn.addActionListener(e -> {
            typeFilterBox.setSelectedIndex(0);
            statusFilterBox.setSelectedIndex(0);
            searchField.setText("");
            tableModel.applyFilter("All", "All", "");
        });

        setVisible(true);
    }

    private void showHallList() {
        mainContent.removeAll();
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Type:"));
        filterPanel.add(typeFilterBox);
        filterPanel.add(new JLabel("Status:"));
        filterPanel.add(statusFilterBox);
        filterPanel.add(new JLabel("Search (ID/Name):"));
        filterPanel.add(searchField);
        filterPanel.add(applyFilterBtn);
        filterPanel.add(refreshBtn);
        filterPanel.add(clearFilterBtn);
        // Add Hall button
        JButton addHallBtn = new JButton("Add Hall");
        filterPanel.add(addHallBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);
        JScrollPane hallScroll = new JScrollPane(hallTable);
        hallScroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(hallScroll, BorderLayout.CENTER);
        mainContent.revalidate();
        mainContent.repaint();
        addHallBtn.addActionListener(e -> {
            HallFormDialog dialog = new HallFormDialog(SwingUtilities.getWindowAncestor(mainContent), null);
            if (dialog.isSucceeded()) {
                tableModel.addHall(dialog.getHall());
            }
        });
    }
    private void showScheduleTab() {
        mainContent.removeAll();
        // Filter/search panel for schedules
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Hall ID:"));
        scheduleTableModel = scheduleTableModel == null ? new ScheduleTableModel() : scheduleTableModel;
        java.util.List<String> hallIds = scheduleTableModel.getAllHallIds();
        scheduleHallFilterBox = new JComboBox<>(hallIds.toArray(new String[0]));
        filterPanel.add(scheduleHallFilterBox);
        filterPanel.add(new JLabel("Type:"));
        scheduleTypeFilterBox = new JComboBox<>(new String[]{"All", "Available", "Maintenance"});
        filterPanel.add(scheduleTypeFilterBox);
        filterPanel.add(new JLabel("Search (ID/Hall/Remarks):"));
        scheduleSearchField = new JTextField(12);
        filterPanel.add(scheduleSearchField);
        scheduleApplyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(scheduleApplyFilterBtn);
        scheduleRefreshBtn = new JButton("Refresh");
        filterPanel.add(scheduleRefreshBtn);
        scheduleClearFilterBtn = new JButton("Clear Filters");
        filterPanel.add(scheduleClearFilterBtn);
        addScheduleBtn = new JButton("Add Schedule");
        filterPanel.add(addScheduleBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        // Schedule table
        scheduleTable = new JTable(scheduleTableModel);
        scheduleTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        scheduleTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        scheduleTable.setRowHeight(32);
        scheduleTable.setShowGrid(false);
        scheduleTable.setFillsViewportHeight(true);
        scheduleTable.setSelectionBackground(new Color(220, 230, 250));
        scheduleTable.setSelectionForeground(new Color(30, 30, 30));
        scheduleTable.getColumn("Actions").setCellRenderer(new ScheduleActionsRenderer());
        scheduleTable.getColumn("Actions").setCellEditor(new ScheduleActionsEditor(scheduleTable, scheduleTableModel));
        JScrollPane scheduleScroll = new JScrollPane(scheduleTable);
        scheduleScroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scheduleScroll, BorderLayout.CENTER);

        // Filter/search actions
        scheduleApplyFilterBtn.addActionListener(e -> scheduleTableModel.applyFilter((String)scheduleHallFilterBox.getSelectedItem(), (String)scheduleTypeFilterBox.getSelectedItem(), scheduleSearchField.getText()));
        scheduleRefreshBtn.addActionListener(e -> scheduleTableModel.loadSchedules());
        scheduleClearFilterBtn.addActionListener(e -> {
            scheduleHallFilterBox.setSelectedIndex(0);
            scheduleTypeFilterBox.setSelectedIndex(0);
            scheduleSearchField.setText("");
            scheduleTableModel.applyFilter("All", "All", "");
        });
        addScheduleBtn.addActionListener(e -> {
            ScheduleFormDialog dialog = new ScheduleFormDialog(SwingUtilities.getWindowAncestor(mainContent), null);
            if (dialog.isSucceeded()) {
                scheduleTableModel.addSchedule(dialog.getSchedule());
            }
        });

        mainContent.revalidate();
        mainContent.repaint();
    }
}

// --- Hall Management Dialog (Full CRUD) ---
class HallManagementDialog extends JDialog {
    private JTable hallTable;
    private HallTableModel tableModel;

    public HallManagementDialog(JFrame parent) {
        super(parent, "Hall Management", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        tableModel = new HallTableModel();
        hallTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(hallTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addBtn = new JButton("Add Hall");
        JButton editBtn = new JButton("Edit Hall");
        JButton deleteBtn = new JButton("Delete Hall");
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addHall());
        editBtn.addActionListener(e -> editHall());
        deleteBtn.addActionListener(e -> deleteHall());

        setVisible(true);
    }

    private void addHall() {
        HallFormDialog dialog = new HallFormDialog(SwingUtilities.getWindowAncestor(this), null);
        if (dialog.isSucceeded()) {
            tableModel.addHall(dialog.getHall());
        }
    }

    private void editHall() {
        int row = hallTable.getSelectedRow();
        if (row >= 0) {
            model.Hall hall = tableModel.getHallAt(row);
            HallFormDialog dialog = new HallFormDialog(SwingUtilities.getWindowAncestor(this), hall);
            if (dialog.isSucceeded()) {
                tableModel.updateHall(row, dialog.getHall());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a hall to edit.");
        }
    }

    private void deleteHall() {
        int row = hallTable.getSelectedRow();
        if (row >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this hall?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeHall(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a hall to delete.");
        }
    }
}

// --- Hall Table Model ---
class HallTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"ID", "Name", "Type", "Status", "Actions"};
    private java.util.List<model.Hall> halls = new java.util.ArrayList<>();
    private java.util.List<model.Hall> filtered = new java.util.ArrayList<>();
    private String typeFilter = "All";
    private String statusFilter = "All";
    private String searchTerm = "";

    public HallTableModel() {
        loadHalls();
    }

    public void loadHalls() {
        halls.clear();
        java.util.List<String> lines = util.FileManager.readFile("halls.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                String id = parts[0].trim(), name = parts[1].trim(), type = parts[2].trim(), status = parts[3].trim();
                model.Hall hall = null;
                switch (type) {
                    case "Auditorium": hall = new model.Auditorium(id, name, status); break;
                    case "Banquet": hall = new model.Banquet(id, name, status); break;
                    case "MeetingRoom": hall = new model.MeetingRoom(id, name, status); break;
                }
                if (hall != null) halls.add(hall);
            }
        }
        applyFilter(typeFilter, statusFilter, searchTerm);
    }

    public void applyFilter(String type, String status, String search) {
        this.typeFilter = type;
        this.statusFilter = status;
        this.searchTerm = search == null ? "" : search.trim().toLowerCase();
        filtered.clear();
        for (model.Hall h : halls) {
            boolean typeMatch = type.equals("All") || h.getType().equalsIgnoreCase(type);
            boolean statusMatch = status.equals("All") || h.getStatus().equalsIgnoreCase(status);
            boolean searchMatch = searchTerm.isEmpty() || h.getId().toLowerCase().contains(searchTerm) || h.getName().toLowerCase().contains(searchTerm);
            if (typeMatch && statusMatch && searchMatch) filtered.add(h);
        }
        fireTableDataChanged();
    }

    private void saveHalls() {
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (model.Hall hall : halls) {
            lines.add(hall.getId() + "," + hall.getName() + "," + hall.getType() + "," + hall.getStatus());
        }
        util.FileManager.writeFile("halls.txt", lines);
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        model.Hall hall = filtered.get(row);
        switch (col) {
            case 0: return hall.getId();
            case 1: return hall.getName();
            case 2: return hall.getType();
            case 3: return hall.getStatus();
            case 4: return "Actions";
        }
        return null;
    }
    public boolean isCellEditable(int row, int col) { return col == 4; }

    public void addHall(model.Hall hall) {
        halls.add(hall);
        saveHalls();
        applyFilter(typeFilter, statusFilter, searchTerm);
    }
    public void updateHall(int row, model.Hall hall) {
        model.Hall orig = filtered.get(row);
        for (int i = 0; i < halls.size(); i++) {
            if (halls.get(i).getId().equals(orig.getId())) {
                halls.set(i, hall);
                break;
            }
        }
        saveHalls();
        applyFilter(typeFilter, statusFilter, searchTerm);
    }
    public void removeHall(int row) {
        model.Hall orig = filtered.get(row);
        halls.removeIf(h -> h.getId().equals(orig.getId()));
        saveHalls();
        applyFilter(typeFilter, statusFilter, searchTerm);
    }
    public model.Hall getHallAt(int row) {
        return filtered.get(row);
    }
}

// --- Actions Cell Renderer and Editor ---
class ActionsRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
    private final JButton editBtn = new JButton("Edit");
    private final JButton deleteBtn = new JButton("Delete");
    public ActionsRenderer() {
        setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
        editBtn.setFocusable(false);
        deleteBtn.setFocusable(false);
        add(editBtn);
        add(deleteBtn);
    }
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
        return this;
    }
}

class ActionsEditor extends AbstractCellEditor implements javax.swing.table.TableCellEditor {
    private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
    private final JButton editBtn = new JButton("Edit");
    private final JButton deleteBtn = new JButton("Delete");
    private JTable table;
    public ActionsEditor(JTable table, HallTableModel model) {
        this.table = table;
        panel.add(editBtn);
        panel.add(deleteBtn);
        editBtn.addActionListener(e -> {
            int row = table.getEditingRow();
            if (row >= 0) {
                model.Hall hall = model.getHallAt(row);
                HallFormDialog dialog = new HallFormDialog(SwingUtilities.getWindowAncestor(table), hall);
                if (dialog.isSucceeded()) {
                    model.updateHall(row, dialog.getHall());
                }
            }
            fireEditingStopped();
        });
        deleteBtn.addActionListener(e -> {
            int row = table.getEditingRow();
            if (row >= 0) {
                int confirm = JOptionPane.showConfirmDialog(table, "Are you sure you want to delete this hall?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    model.removeHall(row);
                }
            }
            fireEditingStopped();
        });
    }
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int col) {
        return panel;
    }
    public Object getCellEditorValue() { return null; }
}

// --- Hall Form Dialog ---
class HallFormDialog extends JDialog {
    private JTextField idField, nameField;
    private JComboBox<String> typeBox, statusBox;
    private boolean succeeded = false;
    private model.Hall hall;

    public HallFormDialog(Window parent, model.Hall hallToEdit) {
        super(parent, hallToEdit == null ? "Add Hall" : "Edit Hall", ModalityType.APPLICATION_MODAL);
        setSize(350, 250);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(5, 2, 10, 10));
        add(new JLabel("ID:"));
        idField = new JTextField();
        add(idField);
        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);
        add(new JLabel("Type:"));
        typeBox = new JComboBox<>(new String[]{"Auditorium", "Banquet", "MeetingRoom"});
        add(typeBox);
        add(new JLabel("Status:"));
        statusBox = new JComboBox<>(new String[]{"Available", "Unavailable", "Maintenance"});
        add(statusBox);
        JButton saveBtn = new JButton("Save");
        add(saveBtn);
        JButton cancelBtn = new JButton("Cancel");
        add(cancelBtn);

        if (hallToEdit != null) {
            idField.setText(hallToEdit.getId());
            idField.setEditable(false);
            nameField.setText(hallToEdit.getName());
            typeBox.setSelectedItem(hallToEdit.getType());
            statusBox.setSelectedItem(hallToEdit.getStatus());
        }

        saveBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String type = (String) typeBox.getSelectedItem();
            String status = (String) statusBox.getSelectedItem();
            if (id.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID and Name are required.");
                return;
            }
            switch (type) {
                case "Auditorium": hall = new model.Auditorium(id, name, status); break;
                case "Banquet": hall = new model.Banquet(id, name, status); break;
                case "MeetingRoom": hall = new model.MeetingRoom(id, name, status); break;
            }
            succeeded = true;
            dispose();
        });
        cancelBtn.addActionListener(e -> dispose());
        setVisible(true);
    }
    public boolean isSucceeded() { return succeeded; }
    public model.Hall getHall() { return hall; }
}

// --- Schedule Management Dialog (Enhanced for Date/Time Range and Remarks) ---
class ScheduleManagementDialog extends JDialog {
    private JTable scheduleTable;
    private ScheduleTableModel tableModel;

    public ScheduleManagementDialog(JFrame parent) {
        super(parent, "Schedule Management", true);
        setSize(900, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        tableModel = new ScheduleTableModel();
        scheduleTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(scheduleTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addBtn = new JButton("Add Schedule");
        JButton editBtn = new JButton("Edit Schedule");
        JButton deleteBtn = new JButton("Delete Schedule");
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addSchedule());
        editBtn.addActionListener(e -> editSchedule());
        deleteBtn.addActionListener(e -> deleteSchedule());

        setVisible(true);
    }

    private void addSchedule() {
        ScheduleFormDialog dialog = new ScheduleFormDialog(javax.swing.SwingUtilities.getWindowAncestor(this), null);
        if (dialog.isSucceeded()) {
            tableModel.addSchedule(dialog.getSchedule());
        }
    }

    private void editSchedule() {
        int row = scheduleTable.getSelectedRow();
        if (row >= 0) {
            model.Schedule schedule = tableModel.getScheduleAt(row);
            ScheduleFormDialog dialog = new ScheduleFormDialog(javax.swing.SwingUtilities.getWindowAncestor(this), schedule);
            if (dialog.isSucceeded()) {
                tableModel.updateSchedule(row, dialog.getSchedule());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a schedule to edit.");
        }
    }

    private void deleteSchedule() {
        int row = scheduleTable.getSelectedRow();
        if (row >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this schedule?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeSchedule(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a schedule to delete.");
        }
    }
}

// --- Schedule Table Model with Filtering and Actions ---
class ScheduleTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"Schedule ID", "Hall ID", "Type", "Start DateTime", "End DateTime", "Remarks", "Actions"};
    private java.util.List<model.Schedule> schedules = new java.util.ArrayList<>();
    private java.util.List<model.Schedule> filtered = new java.util.ArrayList<>();
    private String hallIdFilter = "All";
    private String typeFilter = "All";
    private String searchTerm = "";

    public ScheduleTableModel() {
        loadSchedules();
    }

    public void loadSchedules() {
        schedules.clear();
        java.util.List<String> lines = util.FileManager.readFile("schedules.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String scheduleId = parts[0].trim(), hallId = parts[1].trim(), type = parts[2].trim(), start = parts[3].trim(), end = parts[4].trim(), remarks = parts[5].trim();
                schedules.add(new model.Schedule(scheduleId, hallId, type, start, end, remarks));
            }
        }
        applyFilter(hallIdFilter, typeFilter, searchTerm);
    }

    public void applyFilter(String hallId, String type, String search) {
        this.hallIdFilter = hallId;
        this.typeFilter = type;
        this.searchTerm = search == null ? "" : search.trim().toLowerCase();
        filtered.clear();
        for (model.Schedule s : schedules) {
            boolean hallMatch = hallId.equals("All") || s.getHallId().equalsIgnoreCase(hallId);
            boolean typeMatch = type.equals("All") || s.getType().equalsIgnoreCase(type);
            boolean searchMatch = searchTerm.isEmpty() || s.getScheduleId().toLowerCase().contains(searchTerm) || s.getHallId().toLowerCase().contains(searchTerm) || s.getRemarks().toLowerCase().contains(searchTerm);
            if (hallMatch && typeMatch && searchMatch) filtered.add(s);
        }
        fireTableDataChanged();
    }

    private void saveSchedules() {
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (model.Schedule s : schedules) {
            lines.add(s.getScheduleId() + "," + s.getHallId() + "," + s.getType() + "," + s.getStart() + "," + s.getEnd() + "," + s.getRemarks());
        }
        util.FileManager.writeFile("schedules.txt", lines);
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        model.Schedule s = filtered.get(row);
        switch (col) {
            case 0: return s.getScheduleId();
            case 1: return s.getHallId();
            case 2: return s.getType();
            case 3: return s.getStart();
            case 4: return s.getEnd();
            case 5: return s.getRemarks();
            case 6: return "Actions";
        }
        return null;
    }
    public boolean isCellEditable(int row, int col) { return col == 6; }

    public void addSchedule(model.Schedule schedule) {
        schedules.add(schedule);
        saveSchedules();
        applyFilter(hallIdFilter, typeFilter, searchTerm);
    }
    public void updateSchedule(int row, model.Schedule schedule) {
        model.Schedule orig = filtered.get(row);
        for (int i = 0; i < schedules.size(); i++) {
            if (schedules.get(i).getScheduleId().equals(orig.getScheduleId())) {
                schedules.set(i, schedule);
                break;
            }
        }
        saveSchedules();
        applyFilter(hallIdFilter, typeFilter, searchTerm);
    }
    public void removeSchedule(int row) {
        model.Schedule orig = filtered.get(row);
        schedules.removeIf(s -> s.getScheduleId().equals(orig.getScheduleId()));
        saveSchedules();
        applyFilter(hallIdFilter, typeFilter, searchTerm);
    }
    public model.Schedule getScheduleAt(int row) {
        return filtered.get(row);
    }
    public java.util.List<String> getAllHallIds() {
        java.util.Set<String> ids = new java.util.TreeSet<>();
        for (model.Schedule s : schedules) ids.add(s.getHallId());
        java.util.List<String> list = new java.util.ArrayList<>(ids);
        list.add(0, "All");
        return list;
    }
}

// --- Actions Cell Renderer and Editor for Schedules ---
class ScheduleActionsRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
    private final JButton editBtn = new JButton("Edit");
    private final JButton deleteBtn = new JButton("Delete");
    public ScheduleActionsRenderer() {
        setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
        editBtn.setFocusable(false);
        deleteBtn.setFocusable(false);
        add(editBtn);
        add(deleteBtn);
    }
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
        return this;
    }
}

class ScheduleActionsEditor extends AbstractCellEditor implements javax.swing.table.TableCellEditor {
    private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
    private final JButton editBtn = new JButton("Edit");
    private final JButton deleteBtn = new JButton("Delete");
    private JTable table;
    public ScheduleActionsEditor(JTable table, ScheduleTableModel model) {
        this.table = table;
        panel.add(editBtn);
        panel.add(deleteBtn);
        editBtn.addActionListener(e -> {
            int row = table.getEditingRow();
            if (row >= 0) {
                model.Schedule schedule = model.getScheduleAt(row);
                ScheduleFormDialog dialog = new ScheduleFormDialog(SwingUtilities.getWindowAncestor(table), schedule);
                if (dialog.isSucceeded()) {
                    model.updateSchedule(row, dialog.getSchedule());
                }
            }
            fireEditingStopped();
        });
        deleteBtn.addActionListener(e -> {
            int row = table.getEditingRow();
            if (row >= 0) {
                int confirm = JOptionPane.showConfirmDialog(table, "Are you sure you want to delete this schedule?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    model.removeSchedule(row);
                }
            }
            fireEditingStopped();
        });
    }
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int col) {
        return panel;
    }
    public Object getCellEditorValue() { return null; }
}

// --- Schedule Form Dialog (Enhanced) ---
class ScheduleFormDialog extends JDialog {
    private JTextField hallIdField, startField, endField, remarksField;
    private JComboBox<String> typeBox;
    private boolean succeeded = false;
    private model.Schedule schedule;

    public ScheduleFormDialog(java.awt.Window parent, model.Schedule scheduleToEdit) {
        super(parent, scheduleToEdit == null ? "Add Schedule" : "Edit Schedule", ModalityType.APPLICATION_MODAL);
        setSize(500, 350);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(7, 2, 10, 10));
        add(new JLabel("Hall ID:"));
        hallIdField = new JTextField();
        add(hallIdField);
        add(new JLabel("Type:"));
        typeBox = new JComboBox<>(new String[]{"Available", "Maintenance"});
        add(typeBox);
        add(new JLabel("Start DateTime (yyyy-MM-dd HH:mm):"));
        startField = new JTextField();
        add(startField);
        add(new JLabel("End DateTime (yyyy-MM-dd HH:mm):"));
        endField = new JTextField();
        add(endField);
        add(new JLabel("Remarks (optional):"));
        remarksField = new JTextField();
        add(remarksField);
        JButton saveBtn = new JButton("Save");
        add(saveBtn);
        JButton cancelBtn = new JButton("Cancel");
        add(cancelBtn);

        if (scheduleToEdit != null) {
            hallIdField.setText(scheduleToEdit.getHallId());
            typeBox.setSelectedItem(scheduleToEdit.getType());
            startField.setText(scheduleToEdit.getStart());
            endField.setText(scheduleToEdit.getEnd());
            remarksField.setText(scheduleToEdit.getRemarks());
        }

        saveBtn.addActionListener(e -> {
            String hallId = hallIdField.getText().trim();
            String type = (String) typeBox.getSelectedItem();
            String start = startField.getText().trim();
            String end = endField.getText().trim();
            String remarks = remarksField.getText().trim();
            if (hallId.isEmpty() || start.isEmpty() || end.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hall ID, Start, and End are required.");
                return;
            }
            String scheduleId = scheduleToEdit == null ? ("S" + System.currentTimeMillis()) : scheduleToEdit.getScheduleId();
            schedule = new model.Schedule(scheduleId, hallId, type, start, end, remarks);
            succeeded = true;
            dispose();
        });
        cancelBtn.addActionListener(e -> dispose());
        setVisible(true);
    }
    public boolean isSucceeded() { return succeeded; }
    public model.Schedule getSchedule() { return schedule; }
}

// --- Manager Login Frame ---
class ManagerLoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;

    public ManagerLoginFrame() { this(false); }
    public ManagerLoginFrame(boolean fullWindow) {
        setTitle("Manager Login - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (fullWindow) setExtendedState(JFrame.MAXIMIZED_BOTH); else setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);
        JButton loginButton = new JButton("Login");
        formPanel.add(loginButton);
        statusLabel = new JLabel("");
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());
            model.User manager = authenticateManager(email, password);
            if (manager != null) {
                dispose();
                new ManagerDashboardFrame(manager);
            } else {
                statusLabel.setText("Invalid credentials or not a Manager.");
            }
        });

        setVisible(true);
    }

    private model.User authenticateManager(String email, String password) {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), em = parts[2].trim(), pw = parts[3].trim(), role = parts[4].trim(), status = parts[5].trim();
                if (em.equals(email) && pw.equals(password) && role.equalsIgnoreCase("Manager") && status.equalsIgnoreCase("Active")) {
                    return new model.User(id, name, em, pw, role, status){};
                }
            }
        }
        return null;
    }
}

// --- Manager Dashboard Frame with Sidebar and Tabs ---
class ManagerDashboardFrame extends JFrame {
    private model.User manager;
    private JPanel mainContent;
    private JButton reportsBtn, issuesBtn;
    // Sales Reports tab
    private JComboBox<String> periodBox;
    private JTextArea reportArea;
    // Issues tab
    private JTable issueTable;
    private IssueTableModel issueTableModel;
    private JComboBox<String> statusFilterBox, assignedFilterBox;
    private JTextField searchField;
    private JButton applyFilterBtn, refreshBtn, clearFilterBtn;

    public ManagerDashboardFrame(model.User manager) {
        this.manager = manager;
        setTitle("Manager Dashboard - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(30, 60, 120));
        sidebar.setPreferredSize(new Dimension(320, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));

        JLabel logo = new JLabel("Manager", SwingConstants.CENTER);
        logo.setFont(new Font("Serif", Font.BOLD, 32));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(40));

        reportsBtn = new JButton("Sales Reports");
        reportsBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        reportsBtn.setBackground(new Color(245, 247, 250));
        reportsBtn.setForeground(new Color(30, 30, 30));
        reportsBtn.setFocusPainted(false);
        reportsBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        reportsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(reportsBtn);
        sidebar.add(Box.createVerticalStrut(24));

        issuesBtn = new JButton("Manage Issues");
        issuesBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        issuesBtn.setBackground(new Color(245, 247, 250));
        issuesBtn.setForeground(new Color(30, 30, 30));
        issuesBtn.setFocusPainted(false);
        issuesBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        issuesBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(issuesBtn);
        sidebar.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        logoutBtn.setBackground(new Color(220, 38, 38));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);

        // Main content area
        mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(new Color(245, 247, 250));
        add(mainContent, BorderLayout.CENTER);

        // Tab switching
        reportsBtn.addActionListener(e -> showReportsTab());
        issuesBtn.addActionListener(e -> showIssuesTab());
        logoutBtn.addActionListener(e -> {
            dispose();
            new UnifiedLoginFrame();
        });

        showReportsTab(); // Default
        setVisible(true);
    }

    private void showReportsTab() {
        mainContent.removeAll();
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Period:"));
        periodBox = new JComboBox<>(new String[]{"Weekly", "Monthly", "Yearly"});
        topPanel.add(periodBox);
        JButton viewBtn = new JButton("View Report");
        topPanel.add(viewBtn);
        mainContent.add(topPanel, BorderLayout.NORTH);
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(reportArea);
        scroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scroll, BorderLayout.CENTER);
        viewBtn.addActionListener(e -> showReport((String)periodBox.getSelectedItem()));
        showReport("Weekly");
        mainContent.revalidate();
        mainContent.repaint();
    }
    private void showReport(String period) {
        String periodKey = period.toLowerCase();
        java.util.List<String> receipts = util.FileManager.readFile("receipts.txt");
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        java.util.Map<String, Integer> salesByHall = new java.util.HashMap<>();
        int totalSales = 0;
        int totalBookings = 0;
        java.time.LocalDate now = java.time.LocalDate.now();
        for (String line : receipts) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String receiptId = parts[0].trim();
                String bookingId = parts[1].trim();
                int amount = 0;
                try { amount = Integer.parseInt(parts[2].trim()); } catch (Exception ex) { continue; }
                String dateStr = parts[3].trim();
                java.time.LocalDate date;
                try { date = java.time.LocalDate.parse(dateStr); } catch (Exception ex) { continue; }
                // Find hallId from bookings.txt
                String hallId = null;
                for (String b : bookings) {
                    String[] bparts = b.split(",");
                    if (bparts.length >= 5 && bparts[0].trim().equals(bookingId)) {
                        hallId = bparts[1].trim();
                        break;
                    }
                }
                if (hallId == null) continue;
                boolean include = false;
                switch (periodKey) {
                    case "weekly":
                        java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;
                        if (date.getYear() == now.getYear() && date.get(wf.weekOfWeekBasedYear()) == now.get(wf.weekOfWeekBasedYear())) include = true;
                        break;
                    case "monthly":
                        if (date.getYear() == now.getYear() && date.getMonthValue() == now.getMonthValue()) include = true;
                        break;
                    case "yearly":
                        if (date.getYear() == now.getYear()) include = true;
                        break;
                }
                if (include) {
                    salesByHall.put(hallId, salesByHall.getOrDefault(hallId, 0) + amount);
                    totalSales += amount;
                    totalBookings++;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Sales Report (" + period + ")\n");
        sb.append("==============================\n");
        sb.append("Total Bookings: " + totalBookings + "\n");
        sb.append("Total Sales: Rs. " + totalSales + "\n");
        sb.append("\nSales by Hall:\n");
        for (String hallId : salesByHall.keySet()) {
            sb.append("  Hall " + hallId + ": Rs. " + salesByHall.get(hallId) + "\n");
        }
        reportArea.setText(sb.toString());
    }

    private void showIssuesTab() {
        mainContent.removeAll();
        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Status:"));
        statusFilterBox = new JComboBox<>(new String[]{"All", "Open", "In Progress", "Done", "Closed", "Cancelled"});
        filterPanel.add(statusFilterBox);
        filterPanel.add(new JLabel("Assigned To:"));
        assignedFilterBox = new JComboBox<>(getAllSchedulerIds());
        filterPanel.add(assignedFilterBox);
        filterPanel.add(new JLabel("Search (ID/Desc):"));
        searchField = new JTextField(12);
        filterPanel.add(searchField);
        applyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(applyFilterBtn);
        refreshBtn = new JButton("Refresh");
        filterPanel.add(refreshBtn);
        clearFilterBtn = new JButton("Clear Filters");
        filterPanel.add(clearFilterBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        // Issue table (no actions column)
        issueTableModel = new IssueTableModel();
        issueTable = new JTable(issueTableModel);
        issueTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        issueTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        issueTable.setRowHeight(32);
        issueTable.setShowGrid(false);
        issueTable.setFillsViewportHeight(true);
        issueTable.setSelectionBackground(new Color(220, 230, 250));
        issueTable.setSelectionForeground(new Color(30, 30, 30));
        JScrollPane scroll = new JScrollPane(issueTable);
        scroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scroll, BorderLayout.CENTER);

        // Filter/search actions
        applyFilterBtn.addActionListener(e -> applyIssueFilter());
        refreshBtn.addActionListener(e -> issueTableModel.loadIssues());
        clearFilterBtn.addActionListener(e -> {
            statusFilterBox.setSelectedIndex(0);
            assignedFilterBox.setSelectedIndex(0);
            searchField.setText("");
            applyIssueFilter();
        });

        // Row actions (Edit, Change Status, Assign Scheduler, Delete) via context menu
        JPopupMenu popup = new JPopupMenu();
        JMenuItem editItem = new JMenuItem("Edit Remarks");
        JMenuItem statusItem = new JMenuItem("Change Status");
        JMenuItem assignItem = new JMenuItem("Assign Scheduler");
        JMenuItem deleteItem = new JMenuItem("Delete Issue");
        popup.add(editItem);
        popup.add(statusItem);
        popup.add(assignItem);
        popup.add(deleteItem);
        issueTable.setComponentPopupMenu(popup);
        issueTable.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) showPopup(e);
            }
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) showPopup(e);
            }
            private void showPopup(MouseEvent e) {
                int row = issueTable.rowAtPoint(e.getPoint());
                if (row >= 0) issueTable.setRowSelectionInterval(row, row);
            }
        });
        editItem.addActionListener(e -> editIssueRemarks());
        statusItem.addActionListener(e -> changeIssueStatus());
        assignItem.addActionListener(e -> assignScheduler());
        deleteItem.addActionListener(e -> deleteIssue());

        mainContent.revalidate();
        mainContent.repaint();
    }

    private void applyIssueFilter() {
        String status = (String)statusFilterBox.getSelectedItem();
        String assigned = (String)assignedFilterBox.getSelectedItem();
        String search = searchField.getText();
        issueTableModel.applyFilter(status, assigned, search);
    }

    public void editIssueRemarks() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = issueTableModel.getIssueAt(row);
            String newRemarks = JOptionPane.showInputDialog(this, "Enter remarks/response:", issue.getRemarks());
            if (newRemarks != null) {
                issue.setRemarks(newRemarks);
                issueTableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to edit.");
        }
    }
    public void changeIssueStatus() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = issueTableModel.getIssueAt(row);
            String[] statuses = {"Open", "In Progress", "Done", "Closed", "Cancelled"};
            String newStatus = (String) JOptionPane.showInputDialog(this, "Select new status:", "Change Status", JOptionPane.PLAIN_MESSAGE, null, statuses, issue.getStatus());
            if (newStatus != null && !newStatus.equals(issue.getStatus())) {
                issue.setStatus(newStatus);
                issueTableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to change status.");
        }
    }
    public void assignScheduler() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = issueTableModel.getIssueAt(row);
            java.util.List<String> users = util.FileManager.readFile("users.txt");
            java.util.List<String> schedulers = new java.util.ArrayList<>();
            for (String line : users) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[4].trim().equalsIgnoreCase("Scheduler") && parts[5].trim().equalsIgnoreCase("Active")) {
                    schedulers.add(parts[0].trim() + " - " + parts[1].trim());
                }
            }
            if (schedulers.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No active schedulers found.");
                return;
            }
            String selected = (String) JOptionPane.showInputDialog(this, "Assign Scheduler:", "Assign Scheduler", JOptionPane.PLAIN_MESSAGE, null, schedulers.toArray(), null);
            if (selected != null) {
                String schedulerId = selected.split(" - ")[0];
                issue.setAssignedTo(schedulerId);
                issueTableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to assign a scheduler.");
        }
    }
    public void deleteIssue() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this issue?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                issueTableModel.removeIssue(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to delete.");
        }
    }
    private String[] getAllSchedulerIds() {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("All");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6 && parts[4].trim().equalsIgnoreCase("Scheduler")) {
                ids.add(parts[0].trim());
            }
        }
        return ids.toArray(new String[0]);
    }
}

// --- Sales Report Dialog (Full Implementation) ---
class SalesReportDialog extends JDialog {
    private JTextArea reportArea;
    private JButton weeklyBtn, monthlyBtn, yearlyBtn;

    public SalesReportDialog(JFrame parent) {
        super(parent, "Sales Reports", true);
        setSize(600, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        weeklyBtn = new JButton("Weekly");
        monthlyBtn = new JButton("Monthly");
        yearlyBtn = new JButton("Yearly");
        topPanel.add(new JLabel("View Sales Report:"));
        topPanel.add(weeklyBtn);
        topPanel.add(monthlyBtn);
        topPanel.add(yearlyBtn);
        add(topPanel, BorderLayout.NORTH);

        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(reportArea), BorderLayout.CENTER);

        weeklyBtn.addActionListener(e -> showReport("weekly"));
        monthlyBtn.addActionListener(e -> showReport("monthly"));
        yearlyBtn.addActionListener(e -> showReport("yearly"));

        showReport("weekly"); // Show weekly by default
        setVisible(true);
    }

    private void showReport(String period) {
        java.util.List<String> receipts = util.FileManager.readFile("receipts.txt");
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        java.util.Map<String, Integer> salesByHall = new java.util.HashMap<>();
        int totalSales = 0;
        int totalBookings = 0;
        java.time.LocalDate now = java.time.LocalDate.now();
        for (String line : receipts) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String receiptId = parts[0].trim();
                String bookingId = parts[1].trim();
                int amount = 0;
                try { amount = Integer.parseInt(parts[2].trim()); } catch (Exception ex) { continue; }
                String dateStr = parts[3].trim();
                java.time.LocalDate date;
                try { date = java.time.LocalDate.parse(dateStr); } catch (Exception ex) { continue; }
                // Find hallId from bookings.txt
                String hallId = null;
                for (String b : bookings) {
                    String[] bparts = b.split(",");
                    if (bparts.length >= 5 && bparts[0].trim().equals(bookingId)) {
                        hallId = bparts[1].trim();
                        break;
                    }
                }
                if (hallId == null) continue;
                boolean include = false;
                switch (period) {
                    case "weekly":
                        java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;
                        if (date.getYear() == now.getYear() && date.get(wf.weekOfWeekBasedYear()) == now.get(wf.weekOfWeekBasedYear())) include = true;
                        break;
                    case "monthly":
                        if (date.getYear() == now.getYear() && date.getMonthValue() == now.getMonthValue()) include = true;
                        break;
                    case "yearly":
                        if (date.getYear() == now.getYear()) include = true;
                        break;
                }
                if (include) {
                    salesByHall.put(hallId, salesByHall.getOrDefault(hallId, 0) + amount);
                    totalSales += amount;
                    totalBookings++;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Sales Report (" + period.substring(0, 1).toUpperCase() + period.substring(1) + ")\n");
        sb.append("==============================\n");
        sb.append("Total Bookings: " + totalBookings + "\n");
        sb.append("Total Sales: Rs. " + totalSales + "\n");
        sb.append("\nSales by Hall:\n");
        for (String hallId : salesByHall.keySet()) {
            sb.append("  Hall " + hallId + ": Rs. " + salesByHall.get(hallId) + "\n");
        }
        reportArea.setText(sb.toString());
    }
}

// --- Issue Management Dialog (Full Implementation) ---
class IssueManagementDialog extends JDialog {
    private JTable issueTable;
    private IssueTableModel tableModel;
    private JButton respondBtn, statusBtn, assignBtn, refreshBtn;

    public IssueManagementDialog(JFrame parent) {
        super(parent, "Issue Management", true);
        setSize(800, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        tableModel = new IssueTableModel();
        issueTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(issueTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        respondBtn = new JButton("Respond (Edit Remarks)");
        statusBtn = new JButton("Change Status");
        assignBtn = new JButton("Assign Scheduler");
        refreshBtn = new JButton("Refresh");
        buttonPanel.add(respondBtn);
        buttonPanel.add(statusBtn);
        buttonPanel.add(assignBtn);
        buttonPanel.add(refreshBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        respondBtn.addActionListener(e -> respondToIssue());
        statusBtn.addActionListener(e -> changeStatus());
        assignBtn.addActionListener(e -> assignScheduler());
        refreshBtn.addActionListener(e -> tableModel.loadIssues());

        setVisible(true);
    }

    private void respondToIssue() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = tableModel.getIssueAt(row);
            String newRemarks = JOptionPane.showInputDialog(this, "Enter remarks/response:", issue.getRemarks());
            if (newRemarks != null) {
                issue.setRemarks(newRemarks);
                tableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to respond to.");
        }
    }

    private void changeStatus() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = tableModel.getIssueAt(row);
            String[] statuses = {"Open", "In Progress", "Done", "Closed", "Cancelled"};
            String newStatus = (String) JOptionPane.showInputDialog(this, "Select new status:", "Change Status", JOptionPane.PLAIN_MESSAGE, null, statuses, issue.getStatus());
            if (newStatus != null && !newStatus.equals(issue.getStatus())) {
                issue.setStatus(newStatus);
                tableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to change status.");
        }
    }

    private void assignScheduler() {
        int row = issueTable.getSelectedRow();
        if (row >= 0) {
            model.Issue issue = tableModel.getIssueAt(row);
            // Get all schedulers from users.txt
            java.util.List<String> users = util.FileManager.readFile("users.txt");
            java.util.List<String> schedulers = new java.util.ArrayList<>();
            for (String line : users) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[4].trim().equalsIgnoreCase("Scheduler") && parts[5].trim().equalsIgnoreCase("Active")) {
                    schedulers.add(parts[0].trim() + " - " + parts[1].trim());
                }
            }
            if (schedulers.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No active schedulers found.");
                return;
            }
            String selected = (String) JOptionPane.showInputDialog(this, "Assign Scheduler:", "Assign Scheduler", JOptionPane.PLAIN_MESSAGE, null, schedulers.toArray(), null);
            if (selected != null) {
                String schedulerId = selected.split(" - ")[0];
                issue.setAssignedTo(schedulerId);
                tableModel.updateIssue(row, issue);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an issue to assign a scheduler.");
        }
    }
}

// --- Issue Table Model (no Actions column) ---
class IssueTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"Issue ID", "Customer ID", "Description", "Status", "Assigned To", "Remarks"};
    private java.util.List<model.Issue> issues = new java.util.ArrayList<>();
    private java.util.List<model.Issue> filtered = new java.util.ArrayList<>();
    private String statusFilter = "All";
    private String assignedFilter = "All";
    private String searchTerm = "";

    public IssueTableModel() {
        loadIssues();
    }

    public void loadIssues() {
        issues.clear();
        java.util.List<String> lines = util.FileManager.readFile("issues.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String issueId = parts[0].trim(), customerId = parts[1].trim(), desc = parts[2].trim(), status = parts[3].trim(), assignedTo = parts[4].trim(), remarks = parts[5].trim();
                issues.add(new model.Issue(issueId, customerId, desc, status, assignedTo, remarks));
            }
        }
        applyFilter(statusFilter, assignedFilter, searchTerm);
    }

    public void applyFilter(String status, String assigned, String search) {
        this.statusFilter = status;
        this.assignedFilter = assigned;
        this.searchTerm = search == null ? "" : search.trim().toLowerCase();
        filtered.clear();
        for (model.Issue i : issues) {
            boolean statusMatch = status.equals("All") || i.getStatus().equalsIgnoreCase(status);
            boolean assignedMatch = assigned.equals("All") || i.getAssignedTo().equalsIgnoreCase(assigned);
            boolean searchMatch = searchTerm.isEmpty() || i.getIssueId().toLowerCase().contains(searchTerm) || i.getDescription().toLowerCase().contains(searchTerm);
            if (statusMatch && assignedMatch && searchMatch) filtered.add(i);
        }
        fireTableDataChanged();
    }

    private void saveIssues() {
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (model.Issue i : issues) {
            lines.add(i.getIssueId() + "," + i.getCustomerId() + "," + i.getDescription() + "," + i.getStatus() + "," + i.getAssignedTo() + "," + i.getRemarks());
        }
        util.FileManager.writeFile("issues.txt", lines);
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        model.Issue i = filtered.get(row);
        switch (col) {
            case 0: return i.getIssueId();
            case 1: return i.getCustomerId();
            case 2: return i.getDescription();
            case 3: return i.getStatus();
            case 4: return i.getAssignedTo();
            case 5: return i.getRemarks();
        }
        return null;
    }
    public boolean isCellEditable(int row, int col) { return false; }

    public void updateIssue(int row, model.Issue issue) {
        model.Issue orig = filtered.get(row);
        for (int i = 0; i < issues.size(); i++) {
            if (issues.get(i).getIssueId().equals(orig.getIssueId())) {
                issues.set(i, issue);
                break;
            }
        }
        saveIssues();
        applyFilter(statusFilter, assignedFilter, searchTerm);
    }
    public void removeIssue(int row) {
        model.Issue orig = filtered.get(row);
        issues.removeIf(i -> i.getIssueId().equals(orig.getIssueId()));
        saveIssues();
        applyFilter(statusFilter, assignedFilter, searchTerm);
    }
    public model.Issue getIssueAt(int row) {
        return filtered.get(row);
    }
}

// --- Assign Scheduler Dialog (Stub) ---
class AssignSchedulerDialog extends JDialog {
    public AssignSchedulerDialog(JFrame parent) {
        super(parent, "Assign Scheduler to Issue", true);
        setSize(500, 300);
        setLocationRelativeTo(parent);
        add(new JLabel("[Stub] Assign Scheduler Panel Coming Soon", SwingConstants.CENTER), BorderLayout.CENTER);
        setVisible(true);
    }
}

// --- Administrator Login Frame ---
class AdminLoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;

    public AdminLoginFrame() { this(false); }
    public AdminLoginFrame(boolean fullWindow) {
        setTitle("Administrator Login - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (fullWindow) setExtendedState(JFrame.MAXIMIZED_BOTH); else setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);
        JButton loginButton = new JButton("Login");
        formPanel.add(loginButton);
        statusLabel = new JLabel("");
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());
            model.User admin = authenticateAdmin(email, password);
            if (admin != null) {
                dispose();
                new AdminDashboardFrame(admin);
            } else {
                statusLabel.setText("Invalid credentials or not an Administrator.");
            }
        });

        setVisible(true);
    }

    private model.User authenticateAdmin(String email, String password) {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), em = parts[2].trim(), pw = parts[3].trim(), role = parts[4].trim(), status = parts[5].trim();
                if (em.equals(email) && pw.equals(password) && role.equalsIgnoreCase("Administrator") && status.equalsIgnoreCase("Active")) {
                    return new model.User(id, name, em, pw, role, status){};
                }
            }
        }
        return null;
    }
}

// --- Administrator Dashboard Frame with Sidebar and Tabs ---
class AdminDashboardFrame extends JFrame {
    private model.User admin;
    private JPanel mainContent;
    private JButton usersBtn, bookingsBtn, schedulersBtn;
    // Manage Users tab
    private JTable userTable;
    private UserTableModel userTableModel;
    private JComboBox<String> roleFilterBox, statusFilterBox;
    private JTextField userSearchField;
    private JButton userApplyFilterBtn, userRefreshBtn, userClearFilterBtn;
    // View Bookings tab
    private JTable bookingTable;
    private AllBookingTableModel bookingTableModel;
    private JComboBox<String> hallFilterBox, userFilterBox, timeFilterBox;
    private JTextField dateField;
    private JButton bookingRefreshBtn;
    // Manage Scheduler Staff tab
    private JTable schedulerTable;
    private SchedulerTableModel schedulerTableModel;
    private JComboBox<String> schedulerStatusFilterBox;
    private JTextField schedulerSearchField;
    private JButton schedulerApplyFilterBtn, schedulerRefreshBtn, schedulerClearFilterBtn;

    public AdminDashboardFrame(model.User admin) {
        this.admin = admin;
        setTitle("Administrator Dashboard - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(30, 60, 120));
        sidebar.setPreferredSize(new Dimension(320, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));

        JLabel logo = new JLabel("Administrator", SwingConstants.CENTER);
        logo.setFont(new Font("Serif", Font.BOLD, 32));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(40));

        usersBtn = new JButton("Manage Users");
        usersBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        usersBtn.setBackground(new Color(245, 247, 250));
        usersBtn.setForeground(new Color(30, 30, 30));
        usersBtn.setFocusPainted(false);
        usersBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        usersBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(usersBtn);
        sidebar.add(Box.createVerticalStrut(24));

        bookingsBtn = new JButton("View All Bookings");
        bookingsBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        bookingsBtn.setBackground(new Color(245, 247, 250));
        bookingsBtn.setForeground(new Color(30, 30, 30));
        bookingsBtn.setFocusPainted(false);
        bookingsBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        bookingsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(bookingsBtn);
        sidebar.add(Box.createVerticalStrut(24));

        schedulersBtn = new JButton("Manage Scheduler Staff");
        schedulersBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        schedulersBtn.setBackground(new Color(245, 247, 250));
        schedulersBtn.setForeground(new Color(30, 30, 30));
        schedulersBtn.setFocusPainted(false);
        schedulersBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        schedulersBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(schedulersBtn);
        sidebar.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        logoutBtn.setBackground(new Color(220, 38, 38));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);

        // Main content area
        mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(new Color(245, 247, 250));
        add(mainContent, BorderLayout.CENTER);

        // Tab switching
        usersBtn.addActionListener(e -> showUsersTab());
        bookingsBtn.addActionListener(e -> showBookingsTab());
        schedulersBtn.addActionListener(e -> showSchedulersTab());
        logoutBtn.addActionListener(e -> {
            dispose();
            new UnifiedLoginFrame();
        });

        showUsersTab(); // Default
        setVisible(true);
    }

    private void showUsersTab() {
        mainContent.removeAll();
        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Role:"));
        roleFilterBox = new JComboBox<>(new String[]{"All", "Customer", "Scheduler", "Administrator", "Manager"});
        filterPanel.add(roleFilterBox);
        filterPanel.add(new JLabel("Status:"));
        statusFilterBox = new JComboBox<>(new String[]{"All", "Active", "Blocked"});
        filterPanel.add(statusFilterBox);
        filterPanel.add(new JLabel("Search (ID/Name/Email):"));
        userSearchField = new JTextField(12);
        filterPanel.add(userSearchField);
        userApplyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(userApplyFilterBtn);
        userRefreshBtn = new JButton("Refresh");
        filterPanel.add(userRefreshBtn);
        userClearFilterBtn = new JButton("Clear Filters");
        filterPanel.add(userClearFilterBtn);
        // Add User button
        JButton addUserBtn = new JButton("Add User");
        addUserBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        addUserBtn.setForeground(Color.BLACK);
        addUserBtn.setFocusPainted(false);
        filterPanel.add(addUserBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        // User table
        userTableModel = new UserTableModel();
        userTable = new JTable(userTableModel);
        userTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        userTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        userTable.setRowHeight(32);
        userTable.setShowGrid(false);
        userTable.setFillsViewportHeight(true);
        userTable.setSelectionBackground(new Color(220, 230, 250));
        userTable.setSelectionForeground(new Color(30, 30, 30));
        JScrollPane scroll = new JScrollPane(userTable);
        scroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scroll, BorderLayout.CENTER);

        // Filter/search actions
        userApplyFilterBtn.addActionListener(e -> userTableModel.applyFilter((String)roleFilterBox.getSelectedItem(), (String)statusFilterBox.getSelectedItem()));
        userRefreshBtn.addActionListener(e -> userTableModel.loadUsers());
        userClearFilterBtn.addActionListener(e -> {
            roleFilterBox.setSelectedIndex(0);
            statusFilterBox.setSelectedIndex(0);
            userSearchField.setText("");
            userTableModel.applyFilter("All", "All");
        });

        // Context menu actions
        JPopupMenu popup = new JPopupMenu();
        JMenuItem blockItem = new JMenuItem("Block/Unblock User");
        JMenuItem deleteItem = new JMenuItem("Delete User");
        popup.add(blockItem);
        popup.add(deleteItem);
        userTable.setComponentPopupMenu(popup);
        userTable.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { if (e.isPopupTrigger()) showPopup(e); }
            public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) showPopup(e); }
            private void showPopup(MouseEvent e) {
                int row = userTable.rowAtPoint(e.getPoint());
                if (row >= 0) userTable.setRowSelectionInterval(row, row);
            }
        });
        blockItem.addActionListener(e -> blockUser());
        deleteItem.addActionListener(e -> deleteUser());

        mainContent.revalidate();
        mainContent.repaint();
        addUserBtn.addActionListener(e -> {
            AddUserDialog dialog = new AddUserDialog(SwingUtilities.getWindowAncestor(mainContent));
            if (dialog.isSucceeded()) {
                userTableModel.loadUsers();
            }
        });
    }

    private void showBookingsTab() {
        mainContent.removeAll();
        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Hall:"));
        bookingTableModel = new AllBookingTableModel();
        hallFilterBox = new JComboBox<>(getAllHallIds());
        filterPanel.add(hallFilterBox);
        filterPanel.add(new JLabel("User:"));
        userFilterBox = new JComboBox<>(getAllUserIds());
        filterPanel.add(userFilterBox);
        filterPanel.add(new JLabel("Date (yyyy-MM-dd):"));
        dateField = new JTextField(10);
        filterPanel.add(dateField);
        filterPanel.add(new JLabel("Show:"));
        timeFilterBox = new JComboBox<>(new String[]{"All", "Upcoming", "Past"});
        filterPanel.add(timeFilterBox);
        bookingRefreshBtn = new JButton("Refresh");
        filterPanel.add(bookingRefreshBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        bookingTable = new JTable(bookingTableModel);
        bookingTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        bookingTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        bookingTable.setRowHeight(32);
        bookingTable.setShowGrid(false);
        bookingTable.setFillsViewportHeight(true);
        bookingTable.setSelectionBackground(new Color(220, 230, 250));
        bookingTable.setSelectionForeground(new Color(30, 30, 30));
        JScrollPane scroll = new JScrollPane(bookingTable);
        scroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scroll, BorderLayout.CENTER);

        // Filter actions
        bookingRefreshBtn.addActionListener(e -> applyBookingFilters());
        hallFilterBox.addActionListener(e -> applyBookingFilters());
        userFilterBox.addActionListener(e -> applyBookingFilters());
        timeFilterBox.addActionListener(e -> applyBookingFilters());

        mainContent.revalidate();
        mainContent.repaint();
    }
    private void applyBookingFilters() {
        String hallId = (String) hallFilterBox.getSelectedItem();
        String userId = (String) userFilterBox.getSelectedItem();
        String date = dateField.getText().trim();
        String time = (String) timeFilterBox.getSelectedItem();
        bookingTableModel.applyFilter(hallId, userId, date, time);
    }
    private String[] getAllHallIds() {
        java.util.List<String> halls = util.FileManager.readFile("halls.txt");
        java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("All");
        for (String line : halls) {
            String[] parts = line.split(",");
            if (parts.length > 0) ids.add(parts[0].trim());
        }
        return ids.toArray(new String[0]);
    }
    private String[] getAllUserIds() {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("All");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length > 0) ids.add(parts[0].trim());
        }
        return ids.toArray(new String[0]);
    }

    private void showSchedulersTab() {
        mainContent.removeAll();
        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Status:"));
        schedulerStatusFilterBox = new JComboBox<>(new String[]{"All", "Active", "Blocked"});
        filterPanel.add(schedulerStatusFilterBox);
        filterPanel.add(new JLabel("Search (ID/Name/Email):"));
        schedulerSearchField = new JTextField(12);
        filterPanel.add(schedulerSearchField);
        schedulerApplyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(schedulerApplyFilterBtn);
        schedulerRefreshBtn = new JButton("Refresh");
        filterPanel.add(schedulerRefreshBtn);
        schedulerClearFilterBtn = new JButton("Clear Filters");
        filterPanel.add(schedulerClearFilterBtn);
        // Add Scheduler button
        JButton addSchedulerBtn = new JButton("Add Scheduler");
        addSchedulerBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        addSchedulerBtn.setForeground(Color.BLACK);
        addSchedulerBtn.setFocusPainted(false);
        filterPanel.add(addSchedulerBtn);
        mainContent.add(filterPanel, BorderLayout.NORTH);

        schedulerTableModel = new SchedulerTableModel();
        schedulerTable = new JTable(schedulerTableModel);
        schedulerTable.setFont(new Font("SansSerif", Font.PLAIN, 18));
        schedulerTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
        schedulerTable.setRowHeight(32);
        schedulerTable.setShowGrid(false);
        schedulerTable.setFillsViewportHeight(true);
        schedulerTable.setSelectionBackground(new Color(220, 230, 250));
        schedulerTable.setSelectionForeground(new Color(30, 30, 30));
        JScrollPane scroll = new JScrollPane(schedulerTable);
        scroll.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        mainContent.add(scroll, BorderLayout.CENTER);

        // Filter/search actions
        schedulerApplyFilterBtn.addActionListener(e -> schedulerTableModel.applyFilter((String)schedulerStatusFilterBox.getSelectedItem(), schedulerSearchField.getText()));
        schedulerRefreshBtn.addActionListener(e -> schedulerTableModel.loadSchedulers());
        schedulerClearFilterBtn.addActionListener(e -> {
            schedulerStatusFilterBox.setSelectedIndex(0);
            schedulerSearchField.setText("");
            schedulerTableModel.applyFilter("All", "");
        });

        // Context menu actions
        JPopupMenu popup = new JPopupMenu();
        JMenuItem editItem = new JMenuItem("Edit Scheduler");
        JMenuItem deleteItem = new JMenuItem("Delete Scheduler");
        popup.add(editItem);
        popup.add(deleteItem);
        schedulerTable.setComponentPopupMenu(popup);
        schedulerTable.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { if (e.isPopupTrigger()) showPopup(e); }
            public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) showPopup(e); }
            private void showPopup(MouseEvent e) {
                int row = schedulerTable.rowAtPoint(e.getPoint());
                if (row >= 0) schedulerTable.setRowSelectionInterval(row, row);
            }
        });
        editItem.addActionListener(e -> editScheduler());
        deleteItem.addActionListener(e -> deleteScheduler());

        mainContent.revalidate();
        mainContent.repaint();
        addSchedulerBtn.addActionListener(e -> {
            SchedulerFormDialog dialog = new SchedulerFormDialog(SwingUtilities.getWindowAncestor(mainContent), null);
            if (dialog.isSucceeded()) {
                schedulerTableModel.addScheduler(dialog.getScheduler());
            }
        });
    }
    private void editScheduler() {
        int row = schedulerTable.getSelectedRow();
        if (row >= 0) {
            model.Scheduler scheduler = schedulerTableModel.getSchedulerAt(row);
            SchedulerFormDialog dialog = new SchedulerFormDialog(SwingUtilities.getWindowAncestor(this), scheduler);
            if (dialog.isSucceeded()) {
                schedulerTableModel.updateScheduler(row, dialog.getScheduler());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a scheduler to edit.");
        }
    }
    private void deleteScheduler() {
        int row = schedulerTable.getSelectedRow();
        if (row >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this scheduler?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                schedulerTableModel.removeScheduler(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a scheduler to delete.");
        }
    }

    private void blockUser() {
        int row = userTable.getSelectedRow();
        if (row >= 0) {
            model.User user = userTableModel.getUserAt(row);
            String newStatus = user.getStatus().equalsIgnoreCase("Active") ? "Blocked" : "Active";
            int confirm = JOptionPane.showConfirmDialog(this, "Change status to '" + newStatus + "'?", "Block/Unblock User", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                user.setStatus(newStatus);
                userTableModel.updateUser(row, user);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to block/unblock.");
        }
    }
    private void deleteUser() {
        int row = userTable.getSelectedRow();
        if (row >= 0) {
            model.User user = userTableModel.getUserAt(row);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this user?", "Delete User", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                userTableModel.removeUser(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.");
        }
    }
}

// --- Scheduler Staff Dialog (Full CRUD) ---
class SchedulerStaffDialog extends JDialog {
    private JTable schedulerTable;
    private SchedulerTableModel tableModel;
    private JButton addBtn, editBtn, deleteBtn, refreshBtn;
    private JComboBox<String> statusFilterBox;
    private JTextField searchField;
    private JButton applyFilterBtn;

    public SchedulerStaffDialog(JFrame parent) {
        super(parent, "Manage Scheduler Staff", true);
        setSize(800, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Filter/search panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Status:"));
        statusFilterBox = new JComboBox<>(new String[]{"All", "Active", "Blocked"});
        filterPanel.add(statusFilterBox);
        filterPanel.add(new JLabel("Search (ID/Name/Email):"));
        searchField = new JTextField(15);
        filterPanel.add(searchField);
        applyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(applyFilterBtn);
        add(filterPanel, BorderLayout.NORTH);

        tableModel = new SchedulerTableModel();
        schedulerTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(schedulerTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        addBtn = new JButton("Add Scheduler");
        editBtn = new JButton("Edit Scheduler");
        deleteBtn = new JButton("Delete Scheduler");
        refreshBtn = new JButton("Refresh");
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(refreshBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addScheduler());
        editBtn.addActionListener(e -> editScheduler());
        deleteBtn.addActionListener(e -> deleteScheduler());
        refreshBtn.addActionListener(e -> tableModel.loadSchedulers());
        applyFilterBtn.addActionListener(e -> tableModel.applyFilter((String)statusFilterBox.getSelectedItem(), searchField.getText().trim()));

        setVisible(true);
    }

    private void addScheduler() {
        SchedulerFormDialog dialog = new SchedulerFormDialog(SwingUtilities.getWindowAncestor(this), null);
        if (dialog.isSucceeded()) {
            tableModel.addScheduler(dialog.getScheduler());
        }
    }

    private void editScheduler() {
        int row = schedulerTable.getSelectedRow();
        if (row >= 0) {
            model.Scheduler scheduler = tableModel.getSchedulerAt(row);
            SchedulerFormDialog dialog = new SchedulerFormDialog(SwingUtilities.getWindowAncestor(this), scheduler);
            if (dialog.isSucceeded()) {
                tableModel.updateScheduler(row, dialog.getScheduler());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a scheduler to edit.");
        }
    }

    private void deleteScheduler() {
        int row = schedulerTable.getSelectedRow();
        if (row >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this scheduler?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeScheduler(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a scheduler to delete.");
        }
    }
}

class SchedulerTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"ID", "Name", "Email", "Status"};
    private java.util.List<model.Scheduler> schedulers = new java.util.ArrayList<>();
    private java.util.List<model.Scheduler> filtered = new java.util.ArrayList<>();
    private String statusFilter = "All";
    private String searchTerm = "";

    public SchedulerTableModel() {
        loadSchedulers();
    }

    public void loadSchedulers() {
        schedulers.clear();
        java.util.List<String> lines = util.FileManager.readFile("users.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 6 && parts[4].trim().equalsIgnoreCase("Scheduler")) {
                schedulers.add(new model.Scheduler(parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(), parts[5].trim()));
            }
        }
        applyFilter(statusFilter, searchTerm);
    }

    public void applyFilter(String status, String search) {
        this.statusFilter = status;
        this.searchTerm = search == null ? "" : search.trim().toLowerCase();
        filtered.clear();
        for (model.Scheduler s : schedulers) {
            boolean statusMatch = status.equals("All") || s.getStatus().equalsIgnoreCase(status);
            boolean searchMatch = searchTerm.isEmpty() ||
                s.getId().toLowerCase().contains(searchTerm) ||
                s.getName().toLowerCase().contains(searchTerm) ||
                s.getEmail().toLowerCase().contains(searchTerm);
            if (statusMatch && searchMatch) filtered.add(s);
        }
        fireTableDataChanged();
    }

    private void saveSchedulers() {
        // Save all users, updating only scheduler records
        java.util.List<String> lines = util.FileManager.readFile("users.txt");
        java.util.List<String> updated = new java.util.ArrayList<>();
        int schedIndex = 0;
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 6 && parts[4].trim().equalsIgnoreCase("Scheduler")) {
                if (schedIndex < schedulers.size()) {
                    model.Scheduler s = schedulers.get(schedIndex++);
                    updated.add(s.getId() + "," + s.getName() + "," + s.getEmail() + "," + s.getPassword() + ",Scheduler," + s.getStatus());
                }
            } else {
                updated.add(line);
            }
        }
        // Add any new schedulers
        while (schedIndex < schedulers.size()) {
            model.Scheduler s = schedulers.get(schedIndex++);
            updated.add(s.getId() + "," + s.getName() + "," + s.getEmail() + "," + s.getPassword() + ",Scheduler," + s.getStatus());
        }
        util.FileManager.writeFile("users.txt", updated);
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        model.Scheduler s = filtered.get(row);
        switch (col) {
            case 0: return s.getId();
            case 1: return s.getName();
            case 2: return s.getEmail();
            case 3: return s.getStatus();
        }
        return null;
    }
    public boolean isCellEditable(int row, int col) { return false; }

    public void addScheduler(model.Scheduler scheduler) {
        schedulers.add(scheduler);
        saveSchedulers();
        applyFilter(statusFilter, searchTerm);
    }
    public void updateScheduler(int row, model.Scheduler scheduler) {
        model.Scheduler orig = filtered.get(row);
        for (int i = 0; i < schedulers.size(); i++) {
            if (schedulers.get(i).getId().equals(orig.getId())) {
                schedulers.set(i, scheduler);
                break;
            }
        }
        saveSchedulers();
        applyFilter(statusFilter, searchTerm);
    }
    public void removeScheduler(int row) {
        model.Scheduler orig = filtered.get(row);
        schedulers.removeIf(s -> s.getId().equals(orig.getId()));
        saveSchedulers();
        applyFilter(statusFilter, searchTerm);
    }
    public model.Scheduler getSchedulerAt(int row) {
        return filtered.get(row);
    }
}

// --- Scheduler Form Dialog ---
class SchedulerFormDialog extends JDialog {
    private JTextField idField, nameField, emailField, passwordField;
    private JComboBox<String> statusBox;
    private boolean succeeded = false;
    private model.Scheduler scheduler;

    public SchedulerFormDialog(java.awt.Window parent, model.Scheduler schedulerToEdit) {
        super(parent, schedulerToEdit == null ? "Add Scheduler" : "Edit Scheduler", ModalityType.APPLICATION_MODAL);
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6, 2, 10, 10));
        add(new JLabel("ID:"));
        idField = new JTextField();
        add(idField);
        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);
        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);
        add(new JLabel("Password:"));
        passwordField = new JTextField();
        add(passwordField);
        add(new JLabel("Status:"));
        statusBox = new JComboBox<>(new String[]{"Active", "Blocked"});
        add(statusBox);
        JButton saveBtn = new JButton("Save");
        add(saveBtn);
        JButton cancelBtn = new JButton("Cancel");
        add(cancelBtn);

        if (schedulerToEdit != null) {
            idField.setText(schedulerToEdit.getId());
            idField.setEditable(false);
            nameField.setText(schedulerToEdit.getName());
            emailField.setText(schedulerToEdit.getEmail());
            passwordField.setText(schedulerToEdit.getPassword());
            statusBox.setSelectedItem(schedulerToEdit.getStatus());
        }

        saveBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            String status = (String) statusBox.getSelectedItem();
            if (id.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.");
                return;
            }
            scheduler = new model.Scheduler(id, name, email, password, status);
            succeeded = true;
            dispose();
        });
        cancelBtn.addActionListener(e -> dispose());
        setVisible(true);
    }
    public boolean isSucceeded() { return succeeded; }
    public model.Scheduler getScheduler() { return scheduler; }
}

// --- Manage Users Dialog (Full Implementation) ---
class ManageUsersDialog extends JDialog {
    private JTable userTable;
    private UserTableModel tableModel;
    private JComboBox<String> roleFilterBox, statusFilterBox;
    private JButton blockBtn, deleteBtn, refreshBtn;

    public ManageUsersDialog(JFrame parent) {
        super(parent, "Manage Users", true);
        setSize(800, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Role:"));
        roleFilterBox = new JComboBox<>(new String[]{"All", "Customer", "Scheduler", "Administrator", "Manager"});
        filterPanel.add(roleFilterBox);
        filterPanel.add(new JLabel("Status:"));
        statusFilterBox = new JComboBox<>(new String[]{"All", "Active", "Blocked"});
        filterPanel.add(statusFilterBox);
        JButton applyFilterBtn = new JButton("Apply Filter");
        filterPanel.add(applyFilterBtn);
        add(filterPanel, BorderLayout.NORTH);

        tableModel = new UserTableModel();
        userTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(userTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        blockBtn = new JButton("Block/Unblock User");
        deleteBtn = new JButton("Delete User");
        refreshBtn = new JButton("Refresh");
        buttonPanel.add(blockBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(refreshBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        applyFilterBtn.addActionListener(e -> tableModel.applyFilter((String)roleFilterBox.getSelectedItem(), (String)statusFilterBox.getSelectedItem()));
        blockBtn.addActionListener(e -> blockUser());
        deleteBtn.addActionListener(e -> deleteUser());
        refreshBtn.addActionListener(e -> tableModel.loadUsers());

        setVisible(true);
    }

    private void blockUser() {
        int row = userTable.getSelectedRow();
        if (row >= 0) {
            model.User user = tableModel.getUserAt(row);
            String newStatus = user.getStatus().equalsIgnoreCase("Active") ? "Blocked" : "Active";
            int confirm = JOptionPane.showConfirmDialog(this, "Change status to '" + newStatus + "'?", "Block/Unblock User", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                user.setStatus(newStatus);
                tableModel.updateUser(row, user);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to block/unblock.");
        }
    }

    private void deleteUser() {
        int row = userTable.getSelectedRow();
        if (row >= 0) {
            model.User user = tableModel.getUserAt(row);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this user?", "Delete User", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeUser(row);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.");
        }
    }
}

// --- User Table Model ---
class UserTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"ID", "Name", "Email", "Role", "Status"};
    private java.util.List<model.User> users = new java.util.ArrayList<>();
    private java.util.List<model.User> filtered = new java.util.ArrayList<>();
    private String roleFilter = "All";
    private String statusFilter = "All";

    public UserTableModel() {
        loadUsers();
    }

    public void loadUsers() {
        users.clear();
        java.util.List<String> lines = util.FileManager.readFile("users.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), email = parts[2].trim(), password = parts[3].trim(), role = parts[4].trim(), status = parts[5].trim();
                users.add(new model.User(id, name, email, password, role, status){});
            }
        }
        applyFilter(roleFilter, statusFilter);
    }

    public void applyFilter(String role, String status) {
        this.roleFilter = role;
        this.statusFilter = status;
        filtered.clear();
        for (model.User u : users) {
            boolean roleMatch = role.equals("All") || u.getRole().equalsIgnoreCase(role);
            boolean statusMatch = status.equals("All") || u.getStatus().equalsIgnoreCase(status);
            if (roleMatch && statusMatch) filtered.add(u);
        }
        fireTableDataChanged();
    }

    private void saveUsers() {
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (model.User u : users) {
            lines.add(u.getId() + "," + u.getName() + "," + u.getEmail() + "," + u.getPassword() + "," + u.getRole() + "," + u.getStatus());
        }
        util.FileManager.writeFile("users.txt", lines);
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        model.User u = filtered.get(row);
        switch (col) {
            case 0: return u.getId();
            case 1: return u.getName();
            case 2: return u.getEmail();
            case 3: return u.getRole();
            case 4: return u.getStatus();
        }
        return null;
    }
    public boolean isCellEditable(int row, int col) { return false; }

    public void updateUser(int row, model.User user) {
        // Update in both lists
        model.User orig = filtered.get(row);
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId().equals(orig.getId())) {
                users.set(i, user);
                break;
            }
        }
        filtered.set(row, user);
        saveUsers();
        fireTableDataChanged();
    }
    public void removeUser(int row) {
        model.User orig = filtered.get(row);
        users.removeIf(u -> u.getId().equals(orig.getId()));
        filtered.remove(row);
        saveUsers();
        fireTableDataChanged();
    }
    public model.User getUserAt(int row) {
        return filtered.get(row);
    }
}

// --- View My Bookings Dialog (Customer) ---
class ViewBookingsDialog extends JDialog {
    private JTable bookingTable;
    private MyBookingTableModel tableModel;
    private JComboBox<String> timeFilterBox;
    private JButton cancelBtn, issueBtn, refreshBtn;
    private model.User customer;

    public ViewBookingsDialog(CustomerDashboardFrame parent) {
        super(parent, "My Bookings", true);
        this.customer = parent.customer;
        setSize(900, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Show:"));
        timeFilterBox = new JComboBox<>(new String[]{"All", "Upcoming", "Past"});
        filterPanel.add(timeFilterBox);
        refreshBtn = new JButton("Refresh");
        filterPanel.add(refreshBtn);
        add(filterPanel, BorderLayout.NORTH);

        tableModel = new MyBookingTableModel(customer.getId());
        bookingTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        cancelBtn = new JButton("Cancel Booking");
        issueBtn = new JButton("Raise Issue");
        buttonPanel.add(cancelBtn);
        buttonPanel.add(issueBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        timeFilterBox.addActionListener(e -> tableModel.applyFilter((String)timeFilterBox.getSelectedItem()));
        refreshBtn.addActionListener(e -> tableModel.loadBookings());
        cancelBtn.addActionListener(e -> cancelBooking());
        issueBtn.addActionListener(e -> raiseIssue());

        setVisible(true);
    }

    private void cancelBooking() {
        int row = bookingTable.getSelectedRow();
        if (row >= 0) {
            String[] booking = tableModel.getBookingAt(row);
            String bookingDate = booking[3];
            java.time.LocalDate date = java.time.LocalDate.parse(bookingDate);
            java.time.LocalDate today = java.time.LocalDate.now();
            if (!date.isAfter(today.plusDays(3))) {
                JOptionPane.showMessageDialog(this, "Can only cancel bookings more than 3 days in advance.");
                return;
            }
            // Remove from bookings.txt
            java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
            bookings.removeIf(line -> line.startsWith(booking[0] + ","));
            util.FileManager.writeFile("bookings.txt", bookings);
            JOptionPane.showMessageDialog(this, "Booking cancelled.");
            tableModel.loadBookings();
        } else {
            JOptionPane.showMessageDialog(this, "Select a booking to cancel.");
        }
    }

    private void raiseIssue() {
        int row = bookingTable.getSelectedRow();
        if (row >= 0) {
            String[] booking = tableModel.getBookingAt(row);
            new RaiseIssueDialog(javax.swing.SwingUtilities.getWindowAncestor(this), customer, booking);
        } else {
            JOptionPane.showMessageDialog(this, "Select a booking to raise an issue.");
        }
    }
}

class MyBookingTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"Booking ID", "Hall ID", "User ID", "Date", "Status"};
    private java.util.List<String[]> bookings = new java.util.ArrayList<>();
    private java.util.List<String[]> filtered = new java.util.ArrayList<>();
    private String userId;
    private String timeFilter = "All";

    public MyBookingTableModel(String userId) {
        this.userId = userId;
        loadBookings();
    }

    public void loadBookings() {
        bookings.clear();
        java.util.List<String> lines = util.FileManager.readFile("bookings.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 5 && parts[2].equals(userId)) {
                bookings.add(new String[]{parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(), parts[4].trim()});
            }
        }
        applyFilter(timeFilter);
    }

    public void applyFilter(String time) {
        this.timeFilter = time;
        filtered.clear();
        java.time.LocalDate today = java.time.LocalDate.now();
        for (String[] b : bookings) {
            boolean timeMatch = true;
            try {
                java.time.LocalDate bookingDate = java.time.LocalDate.parse(b[3]);
                if (time.equals("Upcoming")) timeMatch = !bookingDate.isBefore(today);
                else if (time.equals("Past")) timeMatch = bookingDate.isBefore(today);
            } catch (Exception ex) {
                // Ignore parse errors, treat as match
            }
            if (timeMatch) filtered.add(b);
        }
        fireTableDataChanged();
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        return filtered.get(row)[col];
    }
    public boolean isCellEditable(int row, int col) { return false; }
    public String[] getBookingAt(int row) { return filtered.get(row); }
}

// --- Raise Issue Dialog ---
class RaiseIssueDialog extends JDialog {
    public RaiseIssueDialog(java.awt.Window parent, model.User customer, String[] booking) {
        super(parent, "Raise Issue", ModalityType.APPLICATION_MODAL);
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        panel.add(new JLabel("Booking ID:"));
        panel.add(new JLabel(booking[0]));
        panel.add(new JLabel("Hall ID:"));
        panel.add(new JLabel(booking[1]));
        panel.add(new JLabel("Describe Issue:"));
        JTextField descField = new JTextField();
        panel.add(descField);
        JButton submitBtn = new JButton("Submit");
        panel.add(submitBtn);
        add(panel, BorderLayout.CENTER);
        submitBtn.addActionListener(e -> {
            String desc = descField.getText().trim();
            if (desc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter issue description.");
                return;
            }
            String issueId = "I" + System.currentTimeMillis();
            String customerId = customer.getId();
            String assignedTo = ""; // Manager will assign
            String status = "Open";
            String remarks = desc;
            java.util.List<String> issues = util.FileManager.readFile("issues.txt");
            issues.add(issueId + "," + customerId + "," + desc + "," + status + "," + assignedTo + "," + remarks);
            util.FileManager.writeFile("issues.txt", issues);
            JOptionPane.showMessageDialog(this, "Issue submitted to manager.");
            dispose();
        });
        setVisible(true);
    }
}

// --- Customer Login Frame ---
class CustomerLoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;

    public CustomerLoginFrame() { this(false); }
    public CustomerLoginFrame(boolean fullWindow) {
        setTitle("Customer Login - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (fullWindow) setExtendedState(JFrame.MAXIMIZED_BOTH); else setSize(350, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);
        JButton loginButton = new JButton("Login");
        formPanel.add(loginButton);
        JButton registerButton = new JButton("Register");
        formPanel.add(registerButton);
        statusLabel = new JLabel("");
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());
            model.User customer = authenticateCustomer(email, password);
            if (customer != null) {
                dispose();
                new CustomerDashboardFrame(customer);
            } else {
                statusLabel.setText("Invalid credentials or not a Customer.");
            }
        });
        registerButton.addActionListener(e -> {
            dispose();
            new CustomerRegistrationFrame(true);
        });

        setVisible(true);
    }

    private model.User authenticateCustomer(String email, String password) {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), em = parts[2].trim(), pw = parts[3].trim(), role = parts[4].trim(), status = parts[5].trim();
                if (em.equals(email) && pw.equals(password) && role.equalsIgnoreCase("Customer") && status.equalsIgnoreCase("Active")) {
                    return new model.User(id, name, em, pw, role, status){};
                }
            }
        }
        return null;
    }
}

// --- Customer Registration Frame ---
class CustomerRegistrationFrame extends JFrame {
    private JTextField nameField, emailField, passwordField;
    private JLabel nameErrorLabel, emailErrorLabel, passwordErrorLabel, statusLabel;

    public CustomerRegistrationFrame() { this(false); }
    public CustomerRegistrationFrame(boolean fullWindow) {
        setTitle("Sign Up - Hall Booking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (fullWindow) setExtendedState(JFrame.MAXIMIZED_BOTH); else setSize(400, 350);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(16, 16, 16, 16);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel title = new JLabel("Sign Up for Hall Booking", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 36));
        add(title, gbc);
        gbc.gridy++;
        JLabel subtitle = new JLabel("Create your account to book halls.", SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 18));
        subtitle.setForeground(new Color(80, 80, 80));
        add(subtitle, gbc);
        gbc.gridy++;
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));
        // Name
        JPanel nameRow = new JPanel();
        nameRow.setLayout(new BoxLayout(nameRow, BoxLayout.X_AXIS));
        nameRow.setOpaque(false);
        JLabel nameLabel = new JLabel("Name");
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        nameLabel.setPreferredSize(new Dimension(120, 32));
        nameLabel.setMinimumSize(new Dimension(120, 32));
        nameLabel.setMaximumSize(new Dimension(120, 32));
        nameRow.add(nameLabel);
        nameField = new JTextField();
        nameField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        nameField.setMaximumSize(new Dimension(220, 32));
        nameField.setPreferredSize(new Dimension(180, 32));
        nameRow.add(nameField);
        formPanel.add(nameRow);
        nameErrorLabel = new JLabel("");
        nameErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        nameErrorLabel.setForeground(new Color(220, 38, 38));
        nameErrorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(nameErrorLabel);
        formPanel.add(Box.createVerticalStrut(12));
        // Email
        JPanel emailRow = new JPanel();
        emailRow.setLayout(new BoxLayout(emailRow, BoxLayout.X_AXIS));
        emailRow.setOpaque(false);
        JLabel emailLabel = new JLabel("Email");
        emailLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        emailLabel.setPreferredSize(new Dimension(120, 32));
        emailLabel.setMinimumSize(new Dimension(120, 32));
        emailLabel.setMaximumSize(new Dimension(120, 32));
        emailRow.add(emailLabel);
        emailField = new JTextField();
        emailField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        emailField.setMaximumSize(new Dimension(220, 32));
        emailField.setPreferredSize(new Dimension(180, 32));
        emailRow.add(emailField);
        formPanel.add(emailRow);
        emailErrorLabel = new JLabel("");
        emailErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        emailErrorLabel.setForeground(new Color(220, 38, 38));
        emailErrorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(emailErrorLabel);
        formPanel.add(Box.createVerticalStrut(12));
        // Password
        JPanel passwordRow = new JPanel();
        passwordRow.setLayout(new BoxLayout(passwordRow, BoxLayout.X_AXIS));
        passwordRow.setOpaque(false);
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        passwordLabel.setPreferredSize(new Dimension(120, 32));
        passwordLabel.setMinimumSize(new Dimension(120, 32));
        passwordLabel.setMaximumSize(new Dimension(120, 32));
        passwordRow.add(passwordLabel);
        passwordField = new JTextField();
        passwordField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        passwordField.setMaximumSize(new Dimension(220, 32));
        passwordField.setPreferredSize(new Dimension(180, 32));
        passwordRow.add(passwordField);
        formPanel.add(passwordRow);
        passwordErrorLabel = new JLabel("");
        passwordErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        passwordErrorLabel.setForeground(new Color(220, 38, 38));
        passwordErrorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(passwordErrorLabel);
        formPanel.add(Box.createVerticalStrut(18));
        // Signup button
        JButton signupBtn = new JButton("Sign Up");
        signupBtn.setFont(new Font("SansSerif", Font.BOLD, 20));
        signupBtn.setBackground(new Color(245, 247, 250));
        signupBtn.setForeground(new Color(30, 30, 30));
        signupBtn.setFocusPainted(false);
        signupBtn.setBorder(BorderFactory.createLineBorder(new Color(22, 163, 74), 2, true));
        signupBtn.setMaximumSize(new Dimension(300, 40));
        signupBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        JPanel signupBtnPanel = new JPanel();
        signupBtnPanel.setOpaque(false);
        signupBtnPanel.setLayout(new BoxLayout(signupBtnPanel, BoxLayout.X_AXIS));
        signupBtnPanel.add(Box.createHorizontalGlue());
        signupBtnPanel.add(signupBtn);
        signupBtnPanel.add(Box.createHorizontalGlue());
        formPanel.add(signupBtnPanel);
        formPanel.add(Box.createVerticalStrut(16));
        gbc.gridy++;
        gbc.gridwidth = 2;
        add(formPanel, gbc);
        gbc.gridy++;
        statusLabel = new JLabel("", SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        statusLabel.setForeground(new Color(220, 38, 38));
        add(statusLabel, gbc);
        signupBtn.addActionListener(e -> handleSignup());
        setVisible(true);
    }
    private void handleSignup() {
        nameErrorLabel.setText("");
        emailErrorLabel.setText("");
        passwordErrorLabel.setText("");
        statusLabel.setText("");
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        boolean valid = true;
        if (name.isEmpty()) {
            nameErrorLabel.setText("Name is required.");
            valid = false;
        }
        if (email.isEmpty()) {
            emailErrorLabel.setText("Email is required.");
            valid = false;
        } else if (!email.contains("@") || !email.contains(".")) {
            emailErrorLabel.setText("Enter a valid email address.");
            valid = false;
        }
        if (password.isEmpty()) {
            passwordErrorLabel.setText("Password is required.");
            valid = false;
        }
        if (!valid) return;
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 3 && parts[2].trim().equalsIgnoreCase(email)) {
                statusLabel.setText("Email already registered.");
                return;
            }
        }
        String id = String.valueOf(System.currentTimeMillis());
        String newUser = id + "," + name + "," + email + "," + password + ",Customer,Active";
        users.add(newUser);
        util.FileManager.writeFile("users.txt", users);
        JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
        dispose();
        new CustomerLoginFrame(true);
    }
}

// --- Customer Dashboard Frame with Sidebar and Tabs ---
class CustomerDashboardFrame extends JFrame {
    public model.User customer;
    private JPanel mainContent;
    private JButton bookHallBtn, viewBookingsBtn, updateProfileBtn;
    private JButton logoutBtn;

    public CustomerDashboardFrame(model.User customer) {
        this.customer = customer;
        setTitle("Customer Dashboard - Hall Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(30, 60, 120));
        sidebar.setPreferredSize(new Dimension(320, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));

        JLabel logo = new JLabel("Customer", SwingConstants.CENTER);
        logo.setFont(new Font("Serif", Font.BOLD, 32));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(40));

        bookHallBtn = new JButton("Book a Hall");
        bookHallBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        bookHallBtn.setBackground(new Color(245, 247, 250));
        bookHallBtn.setForeground(new Color(30, 30, 30));
        bookHallBtn.setFocusPainted(false);
        bookHallBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        bookHallBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(bookHallBtn);
        sidebar.add(Box.createVerticalStrut(24));

        viewBookingsBtn = new JButton("My Bookings");
        viewBookingsBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        viewBookingsBtn.setBackground(new Color(245, 247, 250));
        viewBookingsBtn.setForeground(new Color(30, 30, 30));
        viewBookingsBtn.setFocusPainted(false);
        viewBookingsBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        viewBookingsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(viewBookingsBtn);
        sidebar.add(Box.createVerticalStrut(24));

        updateProfileBtn = new JButton("Update Profile");
        updateProfileBtn.setFont(new Font("SansSerif", Font.BOLD, 22));
        updateProfileBtn.setBackground(new Color(245, 247, 250));
        updateProfileBtn.setForeground(new Color(30, 30, 30));
        updateProfileBtn.setFocusPainted(false);
        updateProfileBtn.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        updateProfileBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(updateProfileBtn);
        sidebar.add(Box.createVerticalGlue());

        logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        logoutBtn.setBackground(new Color(220, 38, 38));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);

        // Main content area
        mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(new Color(245, 247, 250));
        add(mainContent, BorderLayout.CENTER);

        // Tab switching
        bookHallBtn.addActionListener(e -> showBookHallTab());
        viewBookingsBtn.addActionListener(e -> showBookingsTab());
        updateProfileBtn.addActionListener(e -> showProfileTab());
        logoutBtn.addActionListener(e -> {
            dispose();
            new UnifiedLoginFrame();
        });

        showBookHallTab(); // Default
        setVisible(true);
    }

    private void showBookHallTab() {
        mainContent.removeAll();
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 247, 250));
        panel.add(new HallBookingPanel(this), BorderLayout.CENTER);
        mainContent.add(panel, BorderLayout.CENTER);
        mainContent.revalidate();
        mainContent.repaint();
    }
    private void showBookingsTab() {
        mainContent.removeAll();
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 247, 250));
        panel.add(new MyBookingsPanel(this), BorderLayout.CENTER);
        mainContent.add(panel, BorderLayout.CENTER);
        mainContent.revalidate();
        mainContent.repaint();
    }
    private void showProfileTab() {
        mainContent.removeAll();
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 247, 250));
        panel.add(new UpdateProfilePanel(this), BorderLayout.CENTER);
        mainContent.add(panel, BorderLayout.CENTER);
        mainContent.revalidate();
        mainContent.repaint();
    }

    // --- HallBookingPanel ---
    class HallBookingPanel extends JPanel {
        public HallBookingPanel(CustomerDashboardFrame parent) {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel();
            formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
            formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 10, 40));
            JLabel typeLabel = new JLabel("Hall Type:");
            typeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(typeLabel);
            JComboBox<String> typeBox = new JComboBox<>(new String[]{"All", "Auditorium", "Banquet", "MeetingRoom"});
            typeBox.setAlignmentX(Component.LEFT_ALIGNMENT);
            typeBox.setMaximumSize(new Dimension(180, 28));
            typeBox.setPreferredSize(new Dimension(140, 28));
            formPanel.add(typeBox);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel dateLabel = new JLabel("Date (yyyy-MM-dd):");
            dateLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(dateLabel);
            JTextField dateField = new JTextField();
            dateField.setAlignmentX(Component.LEFT_ALIGNMENT);
            dateField.setMaximumSize(new Dimension(180, 28));
            dateField.setPreferredSize(new Dimension(140, 28));
            formPanel.add(dateField);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel startLabel = new JLabel("Start Time (HH:mm, 08:00-18:00):");
            startLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(startLabel);
            JTextField startTimeField = new JTextField();
            startTimeField.setAlignmentX(Component.LEFT_ALIGNMENT);
            startTimeField.setMaximumSize(new Dimension(120, 28));
            startTimeField.setPreferredSize(new Dimension(90, 28));
            formPanel.add(startTimeField);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel endLabel = new JLabel("End Time (HH:mm, 08:00-18:00):");
            endLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(endLabel);
            JTextField endTimeField = new JTextField();
            endTimeField.setAlignmentX(Component.LEFT_ALIGNMENT);
            endTimeField.setMaximumSize(new Dimension(120, 28));
            endTimeField.setPreferredSize(new Dimension(90, 28));
            formPanel.add(endTimeField);
            formPanel.add(Box.createVerticalStrut(10));
            JButton filterBtn = new JButton("Filter Available Halls");
            filterBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(filterBtn);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel hallLabel = new JLabel("Select Hall:");
            hallLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(hallLabel);
            JComboBox<String> hallBox = new JComboBox<>();
            hallBox.setAlignmentX(Component.LEFT_ALIGNMENT);
            hallBox.setMaximumSize(new Dimension(220, 28));
            hallBox.setPreferredSize(new Dimension(180, 28));
            formPanel.add(hallBox);
            formPanel.add(Box.createVerticalStrut(10));
            JButton bookBtn = new JButton("Book Hall");
            bookBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(bookBtn);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel statusLabel = new JLabel("");
            statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            statusLabel.setForeground(new Color(220, 38, 38));
            formPanel.add(statusLabel);
            add(formPanel, BorderLayout.CENTER);
            java.util.List<model.Hall> availableHalls = new java.util.ArrayList<>();
            filterBtn.addActionListener(e -> {
                String type = (String)typeBox.getSelectedItem();
                String date = dateField.getText().trim();
                String startTime = startTimeField.getText().trim();
                String endTime = endTimeField.getText().trim();
                if (date.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
                    statusLabel.setText("Please enter date, start, and end time.");
                    return;
                }
                if (!isValidTimeRange(startTime, endTime)) {
                    statusLabel.setText("Time must be between 08:00 and 18:00, and end after start.");
                    return;
                }
                availableHalls.clear();
                hallBox.removeAllItems();
                java.util.List<String> lines = util.FileManager.readFile("halls.txt");
                for (String line : lines) {
                    String[] parts = line.split(",");
                    if (parts.length >= 4) {
                        String id = parts[0].trim(), name = parts[1].trim(), hallType = parts[2].trim(), status = parts[3].trim();
                        if ((type.equals("All") || hallType.equalsIgnoreCase(type)) && status.equalsIgnoreCase("Available")) {
                            model.Hall hall = null;
                            switch (hallType) {
                                case "Auditorium": hall = new model.Auditorium(id, name, status); break;
                                case "Banquet": hall = new model.Banquet(id, name, status); break;
                                case "MeetingRoom": hall = new model.MeetingRoom(id, name, status); break;
                            }
                            if (hall != null && hall.isAvailable(date)) {
                                availableHalls.add(hall);
                                hallBox.addItem(id + " - " + name);
                            }
                        }
                    }
                }
                if (availableHalls.isEmpty()) {
                    statusLabel.setText("No available halls found for this date/time/type.");
                } else {
                    statusLabel.setText(availableHalls.size() + " hall(s) available.");
                }
            });
            bookBtn.addActionListener(e -> {
                int idx = hallBox.getSelectedIndex();
                String date = dateField.getText().trim();
                String startTime = startTimeField.getText().trim();
                String endTime = endTimeField.getText().trim();
                if (idx < 0 || availableHalls.isEmpty()) {
                    statusLabel.setText("Please filter and select a hall.");
                    return;
                }
                if (!isValidTimeRange(startTime, endTime)) {
                    statusLabel.setText("Time must be between 08:00 and 18:00, and end after start.");
                    return;
                }
                model.Hall hall = availableHalls.get(idx);
                if (isTimeOverlap(hall.getId(), date, startTime, endTime)) {
                    statusLabel.setText("This hall is already booked for the selected time range.");
                    return;
                }
                boolean booked = hall.bookHall(customer.getId(), date, startTime, endTime);
                if (booked) {
                    java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
                    String lastBooking = bookings.get(bookings.size() - 1);
                    String[] parts = lastBooking.split(",");
                    if (parts.length >= 7 && parts[1].equals(hall.getId()) && parts[2].equals(customer.getId()) && parts[3].equals(date) && parts[4].equals(startTime) && parts[5].equals(endTime)) {
                        String bookingId = parts[0];
                        String bookedHallId = hall.getId();
                        String bookedDate = date;
                        String bookedStartTime = startTime;
                        String bookedEndTime = endTime;
                        new PaymentDialog(SwingUtilities.getWindowAncestor(this), bookingId, bookedHallId, bookedDate, customer.getId(), hall.getType(), startTime, endTime);
                    }
                } else {
                    statusLabel.setText("Booking failed. Hall may no longer be available.");
                }
            });
        }
        private boolean isValidTimeRange(String start, String end) {
            try {
                java.time.LocalTime s = java.time.LocalTime.parse(start);
                java.time.LocalTime e = java.time.LocalTime.parse(end);
                java.time.LocalTime open = java.time.LocalTime.of(8, 0);
                java.time.LocalTime close = java.time.LocalTime.of(18, 0);
                return !s.isBefore(open) && !e.isAfter(close) && e.isAfter(s);
            } catch (Exception ex) {
                return false;
            }
        }
        private boolean isTimeOverlap(String hallId, String date, String start, String end) {
            java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
            java.time.LocalTime s1 = java.time.LocalTime.parse(start);
            java.time.LocalTime e1 = java.time.LocalTime.parse(end);
            for (String line : bookings) {
                String[] parts = line.split(",");
                if (parts.length >= 7 && parts[1].equals(hallId) && parts[3].equals(date)) {
                    java.time.LocalTime s2 = java.time.LocalTime.parse(parts[4]);
                    java.time.LocalTime e2 = java.time.LocalTime.parse(parts[5]);
                    if (!e1.isBefore(s2) && !s1.isAfter(e2)) return true;
                }
            }
            return false;
        }
    }

    // --- MyBookingsPanel ---
    class MyBookingsPanel extends JPanel {
        public MyBookingsPanel(CustomerDashboardFrame parent) {
            setLayout(new BorderLayout());
            JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            filterPanel.add(new JLabel("Show:"));
            JComboBox<String> timeFilterBox = new JComboBox<>(new String[]{"All", "Upcoming", "Past"});
            filterPanel.add(timeFilterBox);
            JButton refreshBtn = new JButton("Refresh");
            filterPanel.add(refreshBtn);
            add(filterPanel, BorderLayout.NORTH);
            MyBookingTableModel tableModel = new MyBookingTableModel(parent.customer.getId()) {
                @Override
                public int getColumnCount() { return super.getColumnCount() + 1; }
                @Override
                public String getColumnName(int col) {
                    if (col == super.getColumnCount()) return "Actions";
                    return super.getColumnName(col);
                }
                @Override
                public Object getValueAt(int row, int col) {
                    if (col == super.getColumnCount()) return "Actions";
                    return super.getValueAt(row, col);
                }
                @Override
                public boolean isCellEditable(int row, int col) { return col == super.getColumnCount(); }
            };
            JTable bookingTable = new JTable(tableModel);
            bookingTable.setRowHeight(32);
            bookingTable.getColumn("Actions").setCellRenderer(new BookingActionsRenderer());
            bookingTable.getColumn("Actions").setCellEditor(new BookingActionsEditor(bookingTable, tableModel, parent, this));
            JScrollPane scrollPane = new JScrollPane(bookingTable);
            add(scrollPane, BorderLayout.CENTER);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            // Remove old Cancel/Raise Issue buttons from panel
            add(buttonPanel, BorderLayout.SOUTH);
            timeFilterBox.addActionListener(e -> tableModel.applyFilter((String)timeFilterBox.getSelectedItem()));
            refreshBtn.addActionListener(e -> tableModel.loadBookings());
        }
    }
    // --- Booking Actions Renderer and Editor ---
    class BookingActionsRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private final JButton cancelBtn = new JButton("Cancel");
        private final JButton issueBtn = new JButton("Raise Issue");
        public BookingActionsRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
            cancelBtn.setFocusable(false);
            issueBtn.setFocusable(false);
            add(cancelBtn);
            add(issueBtn);
        }
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
            return this;
        }
    }
    class BookingActionsEditor extends AbstractCellEditor implements javax.swing.table.TableCellEditor {
        private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        private final JButton cancelBtn = new JButton("Cancel");
        private final JButton issueBtn = new JButton("Raise Issue");
        private JTable table;
        private MyBookingTableModel model;
        private CustomerDashboardFrame parent;
        private JPanel parentPanel;
        public BookingActionsEditor(JTable table, MyBookingTableModel model, CustomerDashboardFrame parent, JPanel parentPanel) {
            this.table = table;
            this.model = model;
            this.parent = parent;
            this.parentPanel = parentPanel;
            panel.add(cancelBtn);
            panel.add(issueBtn);
            cancelBtn.addActionListener(e -> {
                int row = table.getEditingRow();
                if (row >= 0) {
                    String[] booking = model.getBookingAt(row);
                    String bookingDate = booking[3];
                    java.time.LocalDate date = java.time.LocalDate.parse(bookingDate);
                    java.time.LocalDate today = java.time.LocalDate.now();
                    if (!date.isAfter(today.plusDays(3))) {
                        JOptionPane.showMessageDialog(parentPanel, "Can only cancel bookings more than 3 days in advance.");
                        fireEditingStopped();
                        return;
                    }
                    java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
                    bookings.removeIf(line -> line.startsWith(booking[0] + ","));
                    util.FileManager.writeFile("bookings.txt", bookings);
                    JOptionPane.showMessageDialog(parentPanel, "Booking cancelled.");
                    model.loadBookings();
                }
                fireEditingStopped();
            });
            issueBtn.addActionListener(e -> {
                int row = table.getEditingRow();
                if (row >= 0) {
                    String[] booking = model.getBookingAt(row);
                    new RaiseIssueDialog(javax.swing.SwingUtilities.getWindowAncestor(parentPanel), parent.customer, booking);
                } else {
                    JOptionPane.showMessageDialog(parentPanel, "Select a booking to raise an issue.");
                }
                fireEditingStopped();
            });
        }
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int col) {
            return panel;
        }
        public Object getCellEditorValue() { return null; }
    }

    // --- UpdateProfilePanel ---
    class UpdateProfilePanel extends JPanel {
        public UpdateProfilePanel(CustomerDashboardFrame parent) {
            setLayout(new BorderLayout());
            JPanel formPanel = new JPanel();
            formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
            formPanel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
            formPanel.setOpaque(false);
            // Name
            JLabel nameLabel = new JLabel("Name");
            nameLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(nameLabel);
            JTextField nameField = new JTextField(parent.customer.getName());
            nameField.setFont(new Font("SansSerif", Font.PLAIN, 16));
            nameField.setMaximumSize(new Dimension(220, 32));
            nameField.setPreferredSize(new Dimension(180, 32));
            nameField.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(nameField);
            formPanel.add(Box.createVerticalStrut(12));
            // Email
            JLabel emailLabel = new JLabel("Email");
            emailLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            emailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(emailLabel);
            JTextField emailField = new JTextField(parent.customer.getEmail());
            emailField.setFont(new Font("SansSerif", Font.PLAIN, 16));
            emailField.setMaximumSize(new Dimension(220, 32));
            emailField.setPreferredSize(new Dimension(180, 32));
            emailField.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(emailField);
            formPanel.add(Box.createVerticalStrut(12));
            // Password
            JLabel passwordLabel = new JLabel("Password");
            passwordLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            passwordLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(passwordLabel);
            JTextField passwordField = new JTextField(parent.customer.getPassword());
            passwordField.setFont(new Font("SansSerif", Font.PLAIN, 16));
            passwordField.setMaximumSize(new Dimension(220, 32));
            passwordField.setPreferredSize(new Dimension(180, 32));
            passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(passwordField);
            formPanel.add(Box.createVerticalStrut(18));
            // Update button
            JButton updateButton = new JButton("Update");
            updateButton.setFont(new Font("SansSerif", Font.BOLD, 16));
            updateButton.setBackground(new Color(245, 247, 250));
            updateButton.setForeground(new Color(30, 30, 30));
            updateButton.setFocusPainted(false);
            updateButton.setBorder(BorderFactory.createLineBorder(new Color(22, 163, 74), 2, true));
            updateButton.setMaximumSize(new Dimension(160, 32));
            // Align right with input fields
            updateButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
            formPanel.add(updateButton);
            formPanel.add(Box.createVerticalStrut(10));
            JLabel statusLabel = new JLabel("");
            statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
            statusLabel.setForeground(new Color(220, 38, 38));
            statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            formPanel.add(statusLabel);
            add(formPanel, BorderLayout.CENTER);
            updateButton.addActionListener(e -> {
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String password = passwordField.getText().trim();
                if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    statusLabel.setText("All fields are required.");
                    return;
                }
                java.util.List<String> users = util.FileManager.readFile("users.txt");
                for (String line : users) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3 && parts[2].trim().equalsIgnoreCase(email) && !parts[0].trim().equals(parent.customer.getId())) {
                        statusLabel.setText("Email already in use.");
                        return;
                    }
                }
                for (int i = 0; i < users.size(); i++) {
                    String[] parts = users.get(i).split(",");
                    if (parts.length >= 6 && parts[0].trim().equals(parent.customer.getId())) {
                        users.set(i, parent.customer.getId() + "," + name + "," + email + "," + password + ",Customer," + parent.customer.getStatus());
                        break;
                    }
                }
                util.FileManager.writeFile("users.txt", users);
                parent.customer.setName(name);
                parent.customer.setEmail(email);
                parent.customer.setPassword(password);
                JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            });
        }
    }
}

// --- Update Profile Dialog ---
class UpdateProfileDialog extends JDialog {
    private JTextField nameField, emailField, passwordField;
    private JLabel statusLabel;
    private model.User customer;

    public UpdateProfileDialog(CustomerDashboardFrame parent) {
        super(parent, "Update Profile", true);
        this.customer = parent.customer;
        setSize(350, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        formPanel.add(new JLabel("Name:"));
        nameField = new JTextField(customer.getName());
        formPanel.add(nameField);
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField(customer.getEmail());
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        passwordField = new JTextField(customer.getPassword());
        formPanel.add(passwordField);
        JButton updateButton = new JButton("Update");
        formPanel.add(updateButton);
        statusLabel = new JLabel("");
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        updateButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                statusLabel.setText("All fields are required.");
                return;
            }
            // Check if email is used by another user
            java.util.List<String> users = util.FileManager.readFile("users.txt");
            for (String line : users) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[2].trim().equalsIgnoreCase(email) && !parts[0].trim().equals(customer.getId())) {
                    statusLabel.setText("Email already in use.");
                    return;
                }
            }
            // Update in users.txt
            for (int i = 0; i < users.size(); i++) {
                String[] parts = users.get(i).split(",");
                if (parts.length >= 6 && parts[0].trim().equals(customer.getId())) {
                    users.set(i, customer.getId() + "," + name + "," + email + "," + password + ",Customer," + customer.getStatus());
                    break;
                }
            }
            util.FileManager.writeFile("users.txt", users);
            customer.setName(name);
            customer.setEmail(email);
            customer.setPassword(password);
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            dispose();
        });

        setVisible(true);
    }
}

// --- Hall Booking Dialog (Enhanced with Payment and Receipt) ---
class HallBookingDialog extends JDialog {
    private JComboBox<String> typeBox, hallBox;
    private JTextField dateField, startTimeField, endTimeField;
    private JButton filterBtn, bookBtn;
    private JLabel statusLabel;
    private java.util.List<model.Hall> availableHalls = new java.util.ArrayList<>();
    private model.User customer;
    private String bookingId;
    private String bookedHallId;
    private String bookedDate;
    private String bookedStartTime;
    private String bookedEndTime;

    public HallBookingDialog(JFrame parent) {
        super(parent, "Book Hall", true);
        if (parent instanceof CustomerDashboardFrame) {
            this.customer = ((CustomerDashboardFrame)parent).customer;
        }
        setSize(500, 420);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 10, 40));

        JLabel typeLabel = new JLabel("Hall Type:");
        typeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(typeLabel);
        typeBox = new JComboBox<>(new String[]{"All", "Auditorium", "Banquet", "MeetingRoom"});
        typeBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(typeBox);
        formPanel.add(Box.createVerticalStrut(10));

        JLabel dateLabel = new JLabel("Date (yyyy-MM-dd):");
        dateLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(dateLabel);
        dateField = new JTextField();
        dateField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(dateField);
        formPanel.add(Box.createVerticalStrut(10));

        JLabel startLabel = new JLabel("Start Time (HH:mm, 08:00-18:00):");
        startLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(startLabel);
        startTimeField = new JTextField();
        startTimeField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(startTimeField);
        formPanel.add(Box.createVerticalStrut(10));

        JLabel endLabel = new JLabel("End Time (HH:mm, 08:00-18:00):");
        endLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(endLabel);
        endTimeField = new JTextField();
        endTimeField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(endTimeField);
        formPanel.add(Box.createVerticalStrut(10));

        filterBtn = new JButton("Filter Available Halls");
        filterBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(filterBtn);
        formPanel.add(Box.createVerticalStrut(10));

        JLabel hallLabel = new JLabel("Select Hall:");
        hallLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(hallLabel);
        hallBox = new JComboBox<>();
        hallBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(hallBox);
        formPanel.add(Box.createVerticalStrut(10));

        bookBtn = new JButton("Book Hall");
        bookBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(bookBtn);
        formPanel.add(Box.createVerticalStrut(10));

        statusLabel = new JLabel("");
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        statusLabel.setForeground(new Color(220, 38, 38));
        formPanel.add(statusLabel);

        add(formPanel, BorderLayout.CENTER);

        filterBtn.addActionListener(e -> filterHalls());
        bookBtn.addActionListener(e -> bookSelectedHall());

        setVisible(true);
    }

    private void filterHalls() {
        String type = (String)typeBox.getSelectedItem();
        String date = dateField.getText().trim();
        String startTime = startTimeField.getText().trim();
        String endTime = endTimeField.getText().trim();
        if (date.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
            statusLabel.setText("Please enter date, start, and end time.");
            return;
        }
        if (!isValidTimeRange(startTime, endTime)) {
            statusLabel.setText("Time must be between 08:00 and 18:00, and end after start.");
            return;
        }
        availableHalls.clear();
        hallBox.removeAllItems();
        java.util.List<String> lines = util.FileManager.readFile("halls.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                String id = parts[0].trim(), name = parts[1].trim(), hallType = parts[2].trim(), status = parts[3].trim();
                if ((type.equals("All") || hallType.equalsIgnoreCase(type)) && status.equalsIgnoreCase("Available")) {
                    model.Hall hall = null;
                    switch (hallType) {
                        case "Auditorium": hall = new model.Auditorium(id, name, status); break;
                        case "Banquet": hall = new model.Banquet(id, name, status); break;
                        case "MeetingRoom": hall = new model.MeetingRoom(id, name, status); break;
                    }
                    if (hall != null && hall.isAvailable(date)) { // TODO: check for time overlap in future
                        availableHalls.add(hall);
                        hallBox.addItem(id + " - " + name);
                    }
                }
            }
        }
        if (availableHalls.isEmpty()) {
            statusLabel.setText("No available halls found for this date/time/type.");
        } else {
            statusLabel.setText(availableHalls.size() + " hall(s) available.");
        }
    }

    private void bookSelectedHall() {
        int idx = hallBox.getSelectedIndex();
        String date = dateField.getText().trim();
        String startTime = startTimeField.getText().trim();
        String endTime = endTimeField.getText().trim();
        if (idx < 0 || availableHalls.isEmpty()) {
            statusLabel.setText("Please filter and select a hall.");
            return;
        }
        if (!isValidTimeRange(startTime, endTime)) {
            statusLabel.setText("Time must be between 08:00 and 18:00, and end after start.");
            return;
        }
        model.Hall hall = availableHalls.get(idx);
        // Check for time overlap in bookings.txt for this hall/date/time
        if (isTimeOverlap(hall.getId(), date, startTime, endTime)) {
            statusLabel.setText("This hall is already booked for the selected time range.");
            return;
        }
        boolean booked = hall.bookHall(customer.getId(), date, startTime, endTime);
        if (booked) {
            // Find the bookingId just created
            java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
            String lastBooking = bookings.get(bookings.size() - 1);
            String[] parts = lastBooking.split(",");
            if (parts.length >= 7 && parts[1].equals(hall.getId()) && parts[2].equals(customer.getId()) && parts[3].equals(date) && parts[4].equals(startTime) && parts[5].equals(endTime)) {
                bookingId = parts[0];
                bookedHallId = hall.getId();
                bookedDate = date;
                bookedStartTime = startTime;
                bookedEndTime = endTime;
                new PaymentDialog(SwingUtilities.getWindowAncestor(this), bookingId, bookedHallId, bookedDate, customer.getId(), hall.getType(), startTime, endTime);
            }
            dispose();
        } else {
            statusLabel.setText("Booking failed. Hall may no longer be available.");
        }
    }

    private boolean isValidTimeRange(String start, String end) {
        try {
            java.time.LocalTime s = java.time.LocalTime.parse(start);
            java.time.LocalTime e = java.time.LocalTime.parse(end);
            java.time.LocalTime open = java.time.LocalTime.of(8, 0);
            java.time.LocalTime close = java.time.LocalTime.of(18, 0);
            return !s.isBefore(open) && !e.isAfter(close) && e.isAfter(s);
        } catch (Exception ex) {
            return false;
        }
    }

    // Check for time overlap
    private boolean isTimeOverlap(String hallId, String date, String start, String end) {
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        java.time.LocalTime s1 = java.time.LocalTime.parse(start);
        java.time.LocalTime e1 = java.time.LocalTime.parse(end);
        for (String line : bookings) {
            String[] parts = line.split(",");
            if (parts.length >= 7 && parts[1].equals(hallId) && parts[3].equals(date)) {
                java.time.LocalTime s2 = java.time.LocalTime.parse(parts[4]);
                java.time.LocalTime e2 = java.time.LocalTime.parse(parts[5]);
                if (!e1.isBefore(s2) && !s1.isAfter(e2)) return true; // overlap
            }
        }
        return false;
    }
}

// --- Payment Dialog ---
class PaymentDialog extends JDialog {
    public PaymentDialog(java.awt.Window parent, String bookingId, String hallId, String date, String customerId, String hallType, String startTime, String endTime) {
        super(parent, "Payment", ModalityType.APPLICATION_MODAL);
        setSize(350, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.add(new JLabel("Booking ID:"));
        panel.add(new JLabel(bookingId));
        panel.add(new JLabel("Hall ID:"));
        panel.add(new JLabel(hallId));
        panel.add(new JLabel("Date:"));
        panel.add(new JLabel(date));
        panel.add(new JLabel("Hall Type:"));
        panel.add(new JLabel(hallType));
        panel.add(new JLabel("Start Time:"));
        panel.add(new JLabel(startTime));
        panel.add(new JLabel("End Time:"));
        panel.add(new JLabel(endTime));
        double rate = model.Hall.getRatePerHour(hallType);
        java.time.LocalTime s = java.time.LocalTime.parse(startTime);
        java.time.LocalTime endTimeObj = java.time.LocalTime.parse(endTime);
        long minutes = java.time.Duration.between(s, endTimeObj).toMinutes();
        double hours = minutes / 60.0;
        if (minutes % 60 != 0) hours = Math.ceil(hours * 100) / 100.0; // round up to 2 decimals
        double amount = rate * hours;
        panel.add(new JLabel("Amount (RM):"));
        JTextField amountField = new JTextField(String.format("%.2f", amount));
        amountField.setEditable(false);
        panel.add(amountField);
        add(panel, BorderLayout.CENTER);
        JButton payBtn = new JButton("Pay");
        add(payBtn, BorderLayout.SOUTH);
        payBtn.addActionListener(e -> {
            // Save receipt
            String receiptId = "R" + System.currentTimeMillis();
            String today = java.time.LocalDate.now().toString();
            java.util.List<String> receipts = util.FileManager.readFile("receipts.txt");
            receipts.add(receiptId + "," + bookingId + "," + amount + "," + today + "," + customerId);
            util.FileManager.writeFile("receipts.txt", receipts);
            JOptionPane.showMessageDialog(this, "Payment successful!");
            new ReceiptDialog(javax.swing.SwingUtilities.getWindowAncestor(this), receiptId, bookingId, hallId, date, String.format("%.2f", amount), today, customerId);
            dispose();
        });
        setVisible(true);
    }
}

// --- Receipt Dialog ---
class ReceiptDialog extends JDialog {
    public ReceiptDialog(java.awt.Window parent, String receiptId, String bookingId, String hallId, String date, String amount, String paymentDate, String customerId) {
        super(parent, "Receipt", ModalityType.APPLICATION_MODAL);
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        StringBuilder sb = new StringBuilder();
        sb.append("RECEIPT\n");
        sb.append("-----------------------------\n");
        sb.append("Receipt ID: " + receiptId + "\n");
        sb.append("Booking ID: " + bookingId + "\n");
        sb.append("Hall ID: " + hallId + "\n");
        sb.append("Date: " + date + "\n");
        sb.append("Amount: Rs. " + amount + "\n");
        sb.append("Payment Date: " + paymentDate + "\n");
        sb.append("Customer ID: " + customerId + "\n");
        sb.append("-----------------------------\n");
        area.setText(sb.toString());
        add(new JScrollPane(area), BorderLayout.CENTER);
        JButton closeBtn = new JButton("Close");
        add(closeBtn, BorderLayout.SOUTH);
        closeBtn.addActionListener(e -> dispose());
        setVisible(true);
    }
}

// --- Admin View All Bookings Dialog ---
class AdminViewBookingsDialog extends JDialog {
    private JTable bookingTable;
    private AllBookingTableModel tableModel;
    private JComboBox<String> hallFilterBox, userFilterBox, timeFilterBox;
    private JTextField dateField;
    private JButton refreshBtn;

    public AdminViewBookingsDialog(JFrame parent) {
        super(parent, "All Bookings", true);
        setSize(1000, 500);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Top filter panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Hall:"));
        hallFilterBox = new JComboBox<>(getAllHallIds());
        filterPanel.add(hallFilterBox);
        filterPanel.add(new JLabel("User:"));
        userFilterBox = new JComboBox<>(getAllUserIds());
        filterPanel.add(userFilterBox);
        filterPanel.add(new JLabel("Date (yyyy-MM-dd):"));
        dateField = new JTextField(10);
        filterPanel.add(dateField);
        filterPanel.add(new JLabel("Show:"));
        timeFilterBox = new JComboBox<>(new String[]{"All", "Upcoming", "Past"});
        filterPanel.add(timeFilterBox);
        refreshBtn = new JButton("Refresh");
        filterPanel.add(refreshBtn);
        add(filterPanel, BorderLayout.NORTH);

        tableModel = new AllBookingTableModel();
        bookingTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        add(scrollPane, BorderLayout.CENTER);

        // Filter actions
        refreshBtn.addActionListener(e -> applyFilters());
        hallFilterBox.addActionListener(e -> applyFilters());
        userFilterBox.addActionListener(e -> applyFilters());
        timeFilterBox.addActionListener(e -> applyFilters());

        setVisible(true);
    }

    private void applyFilters() {
        String hallId = (String) hallFilterBox.getSelectedItem();
        String userId = (String) userFilterBox.getSelectedItem();
        String date = dateField.getText().trim();
        String time = (String) timeFilterBox.getSelectedItem();
        tableModel.applyFilter(hallId, userId, date, time);
    }

    private String[] getAllHallIds() {
        java.util.List<String> halls = util.FileManager.readFile("halls.txt");
        java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("All");
        for (String line : halls) {
            String[] parts = line.split(",");
            if (parts.length > 0) ids.add(parts[0].trim());
        }
        return ids.toArray(new String[0]);
    }
    private String[] getAllUserIds() {
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("All");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length > 0) ids.add(parts[0].trim());
        }
        return ids.toArray(new String[0]);
    }
}

class AllBookingTableModel extends javax.swing.table.AbstractTableModel {
    private String[] columns = {"Booking ID", "Hall ID", "User ID", "Date", "Status"};
    private java.util.List<String[]> bookings = new java.util.ArrayList<>();
    private java.util.List<String[]> filtered = new java.util.ArrayList<>();
    private String hallId = "All", userId = "All", date = "", time = "All";

    public AllBookingTableModel() {
        loadBookings();
    }

    public void loadBookings() {
        bookings.clear();
        java.util.List<String> lines = util.FileManager.readFile("bookings.txt");
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                bookings.add(new String[]{parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(), parts[4].trim()});
            }
        }
        applyFilter(hallId, userId, date, time);
    }

    public void applyFilter(String hallId, String userId, String date, String time) {
        this.hallId = hallId;
        this.userId = userId;
        this.date = date;
        this.time = time;
        filtered.clear();
        java.time.LocalDate today = java.time.LocalDate.now();
        for (String[] b : bookings) {
            boolean hallMatch = hallId.equals("All") || b[1].equals(hallId);
            boolean userMatch = userId.equals("All") || b[2].equals(userId);
            boolean dateMatch = date.isEmpty() || b[3].equals(date);
            boolean timeMatch = true;
            try {
                java.time.LocalDate bookingDate = java.time.LocalDate.parse(b[3]);
                if (time.equals("Upcoming")) timeMatch = !bookingDate.isBefore(today);
                else if (time.equals("Past")) timeMatch = bookingDate.isBefore(today);
            } catch (Exception ex) {
                // Ignore parse errors, treat as match
            }
            if (hallMatch && userMatch && dateMatch && timeMatch) filtered.add(b);
        }
        fireTableDataChanged();
    }

    public int getRowCount() { return filtered.size(); }
    public int getColumnCount() { return columns.length; }
    public String getColumnName(int col) { return columns[col]; }
    public Object getValueAt(int row, int col) {
        return filtered.get(row)[col];
    }
    public boolean isCellEditable(int row, int col) { return false; }
    public String[] getBookingAt(int row) { return filtered.get(row); }
}

// --- Custom PlaceholderTextField ---
class PlaceholderTextField extends JTextField {
    private String placeholder;
    public PlaceholderTextField(String placeholder) {
        super();
        this.placeholder = placeholder;
        setForeground(new Color(60, 60, 60));
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getText().isEmpty() && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setFont(getFont().deriveFont(Font.ITALIC));
            g2.setColor(new Color(180, 180, 180));
            Insets insets = getInsets();
            g2.drawString(placeholder, insets.left + 4, getHeight() / 2 + getFont().getSize() / 2 - 2);
            g2.dispose();
        }
    }
}
// --- Custom PlaceholderPasswordField ---
class PlaceholderPasswordField extends JPasswordField {
    private String placeholder;
    public PlaceholderPasswordField(String placeholder) {
        super();
        this.placeholder = placeholder;
        setForeground(new Color(60, 60, 60));
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getPassword().length == 0 && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setFont(getFont().deriveFont(Font.ITALIC));
            g2.setColor(new Color(180, 180, 180));
            Insets insets = getInsets();
            g2.drawString(placeholder, insets.left + 4, getHeight() / 2 + getFont().getSize() / 2 - 2);
            g2.dispose();
        }
    }
}

// --- Unified Login Page (Enhanced UI, Improved Spacing & Readability) ---
class UnifiedLoginFrame extends JFrame {
    private PlaceholderTextField emailField;
    private PlaceholderPasswordField passwordField;
    private JComboBox<String> roleBox;
    private JLabel emailErrorLabel, passwordErrorLabel, statusLabel;
    private JButton loginBtn, signupBtn;
    private JPanel signupPanel;

    public UnifiedLoginFrame() {
        setTitle("Login - Hall Booking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(16, 16, 16, 16);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel title = new JLabel("Login to Hall Booking System", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 44));
        add(title, gbc);

        gbc.gridwidth = 2;
        gbc.gridy++;
        JLabel subtitle = new JLabel("Welcome! Please login to continue.", SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 22));
        subtitle.setForeground(new Color(80, 80, 80));
        add(subtitle, gbc);

        gbc.gridwidth = 2;
        gbc.gridy++;
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));

        // Email (horizontal)
        JPanel emailRow = new JPanel();
        emailRow.setLayout(new BoxLayout(emailRow, BoxLayout.X_AXIS));
        emailRow.setOpaque(false);
        JLabel emailLabel = new JLabel("Email");
        emailLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        emailLabel.setPreferredSize(new Dimension(120, 40));
        emailLabel.setMinimumSize(new Dimension(120, 40));
        emailLabel.setMaximumSize(new Dimension(120, 40));
        emailLabel.setHorizontalAlignment(SwingConstants.LEFT);
        emailRow.add(emailLabel);
        emailRow.add(Box.createHorizontalStrut(12));
        emailField = new PlaceholderTextField("e.g. user@example.com");
        emailField.setFont(new Font("SansSerif", Font.PLAIN, 20));
        emailField.setMaximumSize(new Dimension(380, 40));
        emailField.setPreferredSize(new Dimension(380, 40));
        emailField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 2, true),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        emailField.setBackground(new Color(245, 247, 250));
        emailField.setToolTipText("Enter your email");
        emailField.setText("");
        emailField.setCaretColor(new Color(70, 130, 180));
        emailField.setColumns(30);
        emailField.setMargin(new Insets(0, 8, 0, 8));
        emailRow.add(emailField);
        formPanel.add(emailRow);
        JPanel emailErrorRow = new JPanel();
        emailErrorRow.setLayout(new BoxLayout(emailErrorRow, BoxLayout.X_AXIS));
        emailErrorRow.setOpaque(false);
        emailErrorRow.add(Box.createHorizontalStrut(132)); // label width + spacing
        emailErrorLabel = new JLabel("");
        emailErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        emailErrorLabel.setForeground(new Color(220, 38, 38)); // Red 500
        emailErrorLabel.setPreferredSize(new Dimension(380, 20));
        emailErrorRow.add(emailErrorLabel);
        formPanel.add(emailErrorRow);
        formPanel.add(Box.createVerticalStrut(18));

        // Password (horizontal)
        JPanel passwordRow = new JPanel();
        passwordRow.setLayout(new BoxLayout(passwordRow, BoxLayout.X_AXIS));
        passwordRow.setOpaque(false);
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        passwordLabel.setPreferredSize(new Dimension(120, 40));
        passwordLabel.setMinimumSize(new Dimension(120, 40));
        passwordLabel.setMaximumSize(new Dimension(120, 40));
        passwordLabel.setHorizontalAlignment(SwingConstants.LEFT);
        passwordRow.add(passwordLabel);
        passwordRow.add(Box.createHorizontalStrut(12));
        passwordField = new PlaceholderPasswordField("Your password");
        passwordField.setFont(new Font("SansSerif", Font.PLAIN, 20));
        passwordField.setMaximumSize(new Dimension(380, 40));
        passwordField.setPreferredSize(new Dimension(380, 40));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 2, true),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        passwordField.setBackground(new Color(245, 247, 250));
        passwordField.setToolTipText("Enter your password");
        passwordField.setText("");
        passwordField.setCaretColor(new Color(70, 130, 180));
        passwordField.setColumns(30);
        passwordField.setMargin(new Insets(0, 8, 0, 8));
        passwordField.setEchoChar('•');
        passwordRow.add(passwordField);
        formPanel.add(passwordRow);
        JPanel passwordErrorRow = new JPanel();
        passwordErrorRow.setLayout(new BoxLayout(passwordErrorRow, BoxLayout.X_AXIS));
        passwordErrorRow.setOpaque(false);
        passwordErrorRow.add(Box.createHorizontalStrut(132));
        passwordErrorLabel = new JLabel("");
        passwordErrorLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        passwordErrorLabel.setForeground(new Color(220, 38, 38)); // Red 500
        passwordErrorLabel.setPreferredSize(new Dimension(380, 20));
        passwordErrorRow.add(passwordErrorLabel);
        formPanel.add(passwordErrorRow);
        formPanel.add(Box.createVerticalStrut(18));

        // Role
        JLabel roleLabel = new JLabel("Role");
        roleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(roleLabel);
        formPanel.add(Box.createVerticalStrut(6));
        roleBox = new JComboBox<>(new String[]{"Scheduler", "Manager", "Administrator", "Customer"});
        roleBox.setFont(new Font("SansSerif", Font.PLAIN, 20));
        roleBox.setMaximumSize(new Dimension(500, 40));
        roleBox.setPreferredSize(new Dimension(500, 40));
        roleBox.setBackground(new Color(245, 247, 250));
        roleBox.setForeground(new Color(30, 30, 30));
        roleBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 2, true),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        formPanel.add(roleBox);
        formPanel.add(Box.createVerticalStrut(28));

        // Login button
        loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("SansSerif", Font.BOLD, 24));
        loginBtn.setBackground(new Color(245, 247, 250));
        loginBtn.setForeground(new Color(30, 30, 30));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createLineBorder(new Color(30, 60, 120), 2, true));
        loginBtn.setMaximumSize(new Dimension(500, 50));
        loginBtn.setPreferredSize(new Dimension(500, 50));
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        JPanel loginBtnPanel = new JPanel();
        loginBtnPanel.setOpaque(false);
        loginBtnPanel.setLayout(new BoxLayout(loginBtnPanel, BoxLayout.X_AXIS));
        loginBtnPanel.add(Box.createHorizontalGlue());
        loginBtnPanel.add(loginBtn);
        loginBtnPanel.add(Box.createHorizontalGlue());
        formPanel.add(loginBtnPanel);
        formPanel.add(Box.createVerticalStrut(16));

        // Signup panel (for customer role)
        signupPanel = new JPanel();
        signupPanel.setOpaque(false);
        signupPanel.setLayout(new BoxLayout(signupPanel, BoxLayout.Y_AXIS));
        JLabel dontHaveAccount = new JLabel("Don't have an account?");
        dontHaveAccount.setFont(new Font("SansSerif", Font.PLAIN, 18));
        dontHaveAccount.setAlignmentX(Component.CENTER_ALIGNMENT);
        signupBtn = new JButton("Sign up as Customer");
        signupBtn.setFont(new Font("SansSerif", Font.BOLD, 20));
        signupBtn.setBackground(new Color(245, 247, 250));
        signupBtn.setForeground(new Color(30, 30, 30));
        signupBtn.setFocusPainted(false);
        signupBtn.setBorder(BorderFactory.createLineBorder(new Color(22, 163, 74), 2, true));
        signupBtn.setMaximumSize(new Dimension(300, 40));
        signupBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupPanel.add(dontHaveAccount);
        signupPanel.add(Box.createVerticalStrut(8));
        signupPanel.add(signupBtn);
        formPanel.add(signupPanel);
        signupPanel.setVisible(roleBox.getSelectedItem().equals("Customer"));

        // Show/hide signup link based on role
        roleBox.addActionListener(e -> {
            signupPanel.setVisible(roleBox.getSelectedItem().equals("Customer"));
        });
        signupBtn.addActionListener(e -> {
            dispose();
            new CustomerRegistrationFrame(true);
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        add(formPanel, gbc);

        gbc.gridy++;
        statusLabel = new JLabel("", SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));
        statusLabel.setForeground(new Color(220, 38, 38));
        add(statusLabel, gbc);

        loginBtn.addActionListener(e -> handleLogin());
        setVisible(true);
    }

    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String) roleBox.getSelectedItem();
        boolean valid = true;
        emailErrorLabel.setText("");
        passwordErrorLabel.setText("");
        statusLabel.setText("");
        if (email.isEmpty()) {
            emailErrorLabel.setText("Email is required.");
            valid = false;
        } else if (!email.contains("@") || !email.contains(".")) {
            emailErrorLabel.setText("Enter a valid email address.");
            valid = false;
        }
        if (password.isEmpty()) {
            passwordErrorLabel.setText("Password is required.");
            valid = false;
        }
        if (!valid) return;
        java.util.List<String> users = util.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String id = parts[0].trim(), name = parts[1].trim(), em = parts[2].trim(), pw = parts[3].trim(), userRole = parts[4].trim(), status = parts[5].trim();
                if (em.equals(email) && pw.equals(password) && userRole.equalsIgnoreCase(role) && status.equalsIgnoreCase("Active")) {
                    dispose();
                    switch (role) {
                        case "Scheduler": new SchedulerDashboardFrame(new model.Scheduler(id, name, em, pw, status)); break;
                        case "Manager": new ManagerDashboardFrame(new model.User(id, name, em, pw, userRole, status){}); break;
                        case "Administrator": new AdminDashboardFrame(new model.User(id, name, em, pw, userRole, status){}); break;
                        case "Customer": new CustomerDashboardFrame(new model.User(id, name, em, pw, userRole, status){}); break;
                    }
                    return;
                }
            }
        }
        statusLabel.setText("Invalid credentials or role.");
    }
}

// AddUserDialog implementation
class AddUserDialog extends JDialog {
    private JTextField idField, nameField, emailField, passwordField;
    private JComboBox<String> roleBox, statusBox;
    private boolean succeeded = false;
    public AddUserDialog(Window parent) {
        super(parent, "Add User", ModalityType.APPLICATION_MODAL);
        setSize(400, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(24, 40, 24, 40));
        formPanel.add(new JLabel("ID"));
        idField = new JTextField(String.valueOf(System.currentTimeMillis()));
        formPanel.add(idField);
        formPanel.add(new JLabel("Name"));
        nameField = new JTextField();
        formPanel.add(nameField);
        formPanel.add(new JLabel("Email"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password"));
        passwordField = new JTextField();
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Role"));
        roleBox = new JComboBox<>(new String[]{"Customer", "Scheduler", "Administrator", "Manager"});
        formPanel.add(roleBox);
        formPanel.add(new JLabel("Status"));
        statusBox = new JComboBox<>(new String[]{"Active", "Blocked"});
        formPanel.add(statusBox);
        add(formPanel, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        JButton saveBtn = new JButton("Save");
        saveBtn.setMaximumSize(new Dimension(120, 32));
        saveBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        bottomPanel.add(saveBtn);
        JLabel errorLabel = new JLabel("");
        errorLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        errorLabel.setForeground(new Color(220, 38, 38));
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        bottomPanel.add(errorLabel);
        add(bottomPanel, BorderLayout.SOUTH);
        saveBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            String role = (String) roleBox.getSelectedItem();
            String status = (String) statusBox.getSelectedItem();
            if (id.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                errorLabel.setText("All fields are required.");
                return;
            }
            java.util.List<String> users = util.FileManager.readFile("users.txt");
            for (String line : users) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[2].trim().equalsIgnoreCase(email)) {
                    errorLabel.setText("Email already exists.");
                    return;
                }
            }
            users.add(id + "," + name + "," + email + "," + password + "," + role + "," + status);
            util.FileManager.writeFile("users.txt", users);
            succeeded = true;
            dispose();
        });
        setVisible(true);
    }
    public boolean isSucceeded() { return succeeded; }
}