package model;

public class Issue {
    private String issueId;
    private String customerId;
    private String description;
    private String status;
    private String assignedTo;
    private String remarks;

    public Issue(String issueId, String customerId, String description, String status, String assignedTo, String remarks) {
        this.issueId = issueId;
        this.customerId = customerId;
        this.description = description;
        this.status = status;
        this.assignedTo = assignedTo;
        this.remarks = remarks;
    }

    public String getIssueId() { return issueId; }
    public void setIssueId(String issueId) { this.issueId = issueId; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
} 