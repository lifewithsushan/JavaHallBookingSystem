package model;

public class MeetingRoom extends Hall {
    public MeetingRoom(String id, String name, String status) {
        super(id, name, "MeetingRoom", status);
    }
    // Additional MeetingRoom-specific methods can be added here
} 