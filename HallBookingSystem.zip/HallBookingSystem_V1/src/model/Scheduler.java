package model;

public class Scheduler extends User {
    public Scheduler(String id, String name, String email, String password, String status) {
        super(id, name, email, password, "Scheduler", status);
    }
    // Additional Scheduler-specific methods can be added here
} 