package model;

public abstract class Hall {
    protected String id;
    protected String name;
    protected String type;
    protected String status;

    public Hall(String id, String name, String type, String status) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.status = status;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    /**
     * Check if the hall is available for a given date.
     * @param date The date to check (format: yyyy-MM-dd)
     * @return true if available, false otherwise
     */
    public boolean isAvailable(String date) {
        // Check schedules.txt for maintenance or unavailable
        java.util.List<String> schedules = util.FileManager.readFile("schedules.txt");
        for (String line : schedules) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String hallId = parts[1].trim();
                String schedDate = parts[2].trim();
                String type = parts[3].trim();
                if (hallId.equals(this.id) && schedDate.equals(date)) {
                    if (!type.equalsIgnoreCase("Available")) return false;
                }
            }
        }
        // Check bookings.txt for existing booking
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        for (String line : bookings) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String hallId = parts[1].trim();
                String bookingDate = parts[3].trim();
                String status = parts[4].trim();
                if (hallId.equals(this.id) && bookingDate.equals(date) && status.equalsIgnoreCase("Confirmed")) {
                    return false;
                }
            }
        }
        return true;
    }

    // Overload for old usage
    public boolean bookHall(String customerId, String date) {
        // Deprecated: use new method with time
        return bookHall(customerId, date, "08:00", "18:00");
    }
    // New method with time
    public boolean bookHall(String customerId, String date, String startTime, String endTime) {
        // Optionally, check for time overlap here
        String bookingId = "B" + System.currentTimeMillis();
        String line = bookingId + "," + this.id + "," + customerId + "," + date + "," + startTime + "," + endTime + ",Confirmed";
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        bookings.add(line);
        util.FileManager.writeFile("bookings.txt", bookings);
        return true;
    }

    /**
     * Cancel a booking for a given customer and date.
     * @param customerId The ID of the customer
     * @param date The booking date
     * @return true if cancellation is successful, false otherwise
     */
    public boolean cancelBooking(String customerId, String date) {
        java.util.List<String> bookings = util.FileManager.readFile("bookings.txt");
        boolean found = false;
        java.util.List<String> updated = new java.util.ArrayList<>();
        for (String line : bookings) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String hallId = parts[1].trim();
                String custId = parts[2].trim();
                String bookingDate = parts[3].trim();
                if (hallId.equals(this.id) && custId.equals(customerId) && bookingDate.equals(date)) {
                    found = true; // skip this booking (cancel)
                    continue;
                }
            }
            updated.add(line);
        }
        if (found) {
            util.FileManager.writeFile("bookings.txt", updated);
        }
        return found;
    }

    /**
     * Set the hall's availability or maintenance schedule for a date.
     * @param date The date
     * @param type "Available" or "Maintenance"
     * @param remarks Remarks for the schedule
     */
    public void setSchedule(String date, String type, String remarks) {
        java.util.List<String> schedules = util.FileManager.readFile("schedules.txt");
        boolean updated = false;
        for (int i = 0; i < schedules.size(); i++) {
            String[] parts = schedules.get(i).split(",");
            if (parts.length >= 5) {
                String hallId = parts[1].trim();
                String schedDate = parts[2].trim();
                if (hallId.equals(this.id) && schedDate.equals(date)) {
                    schedules.set(i, parts[0] + "," + this.id + "," + date + "," + type + "," + remarks);
                    updated = true;
                    break;
                }
            }
        }
        if (!updated) {
            String scheduleId = "S" + System.currentTimeMillis();
            schedules.add(scheduleId + "," + this.id + "," + date + "," + type + "," + remarks);
        }
        util.FileManager.writeFile("schedules.txt", schedules);
    }

    /**
     * Get the schedule/remark for a given date.
     * @param date The date
     * @return The schedule type and remarks, or null if none
     */
    public String getSchedule(String date) {
        java.util.List<String> schedules = util.FileManager.readFile("schedules.txt");
        for (String line : schedules) {
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                String hallId = parts[1].trim();
                String schedDate = parts[2].trim();
                if (hallId.equals(this.id) && schedDate.equals(date)) {
                    return parts[3].trim() + ": " + parts[4].trim();
                }
            }
        }
        return null;
    }

    // --- Booking rates and capacities ---
    public static double getRatePerHour(String type) {
        switch (type) {
            case "Auditorium": return 300.0;
            case "Banquet": return 100.0;
            case "MeetingRoom": return 50.0;
            default: return 0.0;
        }
    }
    public static int getCapacity(String type) {
        switch (type) {
            case "Auditorium": return 1000;
            case "Banquet": return 300;
            case "MeetingRoom": return 30;
            default: return 0;
        }
    }
} 