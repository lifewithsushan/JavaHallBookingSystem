package model;

public class Schedule {
    private String scheduleId;
    private String hallId;
    private String type; // "Available" or "Maintenance"
    private String start; // Start date-time (yyyy-MM-dd HH:mm)
    private String end;   // End date-time (yyyy-MM-dd HH:mm)
    private String remarks;

    public Schedule(String scheduleId, String hallId, String type, String start, String end, String remarks) {
        this.scheduleId = scheduleId;
        this.hallId = hallId;
        this.type = type;
        this.start = start;
        this.end = end;
        this.remarks = remarks;
    }

    // Getters and setters
    public String getScheduleId() { return scheduleId; }
    public void setScheduleId(String scheduleId) { this.scheduleId = scheduleId; }
    public String getHallId() { return hallId; }
    public void setHallId(String hallId) { this.hallId = hallId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getStart() { return start; }
    public void setStart(String start) { this.start = start; }
    public String getEnd() { return end; }
    public void setEnd(String end) { this.end = end; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
} 