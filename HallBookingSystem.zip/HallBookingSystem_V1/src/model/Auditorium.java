package model;

public class Auditorium extends Hall {
    public Auditorium(String id, String name, String status) {
        super(id, name, "Auditorium", status);
    }
    // Additional Auditorium-specific methods can be added here
} 