package model;

public class Banquet extends Hall {
    public Banquet(String id, String name, String status) {
        super(id, name, "Banquet", status);
    }
    // Additional Banquet-specific methods can be added here
} 